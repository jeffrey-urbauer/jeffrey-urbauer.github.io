See ?share and ?share,contents for information about the share library
Share Library:  guesss
Author: Derksen, Harm.
Description:  routine to guess the next values in a sequence
OK

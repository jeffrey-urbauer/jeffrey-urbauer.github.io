See ?share and ?share,contents for information about the share library
Share Library:  pvac
Author: Monagan, Michael.
Description:  Print vectors as column vectors.
Warning, new definition for norm
Warning, new definition for trace
MATRIX([[1], [2], [3]])
VECTOR([1, 2, 3])
VECTOR([1, 2, 3])
b := MATRIX([[1, 2], [3, 4]])
row := MATRIX([[1, 2]])
col := MATRIX([[1], [2]])
MATRIX([[1, 2]])
MATRIX([[1], [2]])

See ?share and ?share,contents for information about the share library
Share Library:  rainbow
Author: Joyner, David.
Description:  The rainbow share package contains routines to simulate the
moves of the masterball (a Rubik's cube-like puzzle in the shape of
a sphere).
ok
ok
ok

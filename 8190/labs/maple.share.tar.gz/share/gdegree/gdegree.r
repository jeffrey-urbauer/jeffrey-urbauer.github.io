See ?share and ?share,contents for information about the share library
Share Library:  gdegree
Author: Monagan, Michael.
Description:  an example of programming with Maple expressions - recursive method to calculate the degree of an expression
okay
okay
okay

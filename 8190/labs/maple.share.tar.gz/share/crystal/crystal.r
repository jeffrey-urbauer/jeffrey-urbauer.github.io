See ?share and ?share,contents for information about the share library
Share Library:  coxeter
Author: John Stembridge.
Description:  The coxeter package contains 30 basic procedures for studying roots systems and finite Coxeter groups.  It can be used with The weyl package which contains an additional seven procedures for manipulating weight vectors and computing multiplicities for irreducible representations of semisimple Lie algebras.
Share Library:  weyl
Author: John Stembridge.
Description:  The weyl package is a supplement to the coxeter package that contains 7 procedures for manipulating weight vectors and computing multiplicities for irreducible representations of semisimple Lie algebras.
Share Library:  crystal
Authors: Joyner, David, Martin, Roland, Fourte, Michael.
Description:  A Maple package which decomposes the tensor product of two irreducible finite dimensional "fundamental" representations of a simple Lie algebra into irreducible constituents using "crystal" graphs.  This is an implementation of a theorem of Kashiwara.
Warning, new definition for weight_coords
init()
ok
`Graph formed.`
ok
ok
`Graph formed.`
`Graph formed.`
ok
ok
`Graph formed.`
ok
ok

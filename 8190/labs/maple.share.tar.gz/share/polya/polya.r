See ?share and ?share,contents for information about the share library
Share Library:  polya
Author: Fiegelstock, Shalom.
Description:  Isomers, Groups and Combinatorics: A description and application of Polya's Theorem (from Group theory) to the enumeration of benzene isomers and counting necklace patterns with beads of different colours.
okay
okay
okay
okay

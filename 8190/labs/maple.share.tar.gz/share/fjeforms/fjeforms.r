See ?share and ?share,contents for information about the share library
Share Library:  fjeforms
Author: Ernst, Fred.
Description:  As part of a continuing assessment of the potential of various general purpose symbolic manipulation programs for handling research level problems involving differential forms, we have rewritten a number of application programs that were originally written for Ernst's Grad Student Rational Calculator.  Getting these programs to work under Maple required the modification and enhancement of the difforms package.  The revised package developed by FJE ENTERPRISES has the name fjeforms.
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay

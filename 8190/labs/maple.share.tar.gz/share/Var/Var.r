See ?share and ?share,contents for information about the share library
Share Library:  Var
Author: Marvan, Michal.
Description:  routines for the direct and the inverse problem of the calculus of variations
`Variationality test positive`
`Variationality test positive`

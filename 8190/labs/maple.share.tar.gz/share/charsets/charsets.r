See ?share and ?share,contents for information about the share library
Share Library:  charsets
Author: Dongming Wang.
Description:  A implementation of Ritt-Wu's characteristic sets method.Includes characteristic sets of (multivariate) polynomial sets,decomposing polynomial sets into ascending sets and irreducible ascending sets, decomposing algebraic varieties into irreducible components, factorizing polynomials over algebraic number fields and solving systems of polynomial equations.
Warning, `i` is implicitly declared local
CharSets/Test:   `charsets/charset`-` `   Good
CharSets/Test:   `charsets/charset`-basset   Good
CharSets/Test:   `charsets/charset`-wbasset   Good
CharSets/Test:   `charsets/charset`-qbasset   Good
CharSets/Test:   `charsets/charset`-charsetn   Good
CharSets/Test:   `charsets/charset`-wcharsetn   Good
CharSets/Test:   `charsets/charset`-qcharsetn   Good
CharSets/Test:   `charsets/charset`-triset   Good
CharSets/Test:   `charsets/charset`-trisetc   Good
CharSets/Test:   `charsets/mcharset`-` `   Good
CharSets/Test:   `charsets/mcharset`-basset   Good
CharSets/Test:   `charsets/mcharset`-wbasset   Good
CharSets/Test:   `charsets/mcharset`-qbasset   Good
CharSets/Test:   `charsets/mcharset`-charsetn   Good
CharSets/Test:   `charsets/mcharset`-wcharsetn   Good
CharSets/Test:   `charsets/mcharset`-qcharsetn   Good
CharSets/Test:   `charsets/mcharset`-triset   Good
CharSets/Test:   `charsets/mcharset`-trisetc   Good
CharSets/Test:   `charsets/iniset`-` `   Good
CharSets/Test:   `charsets/remset`-` `   Good
CharSets/Test:   `charsets/charser`-` `   Good
CharSets/Test:   `charsets/charser`-basset   Good
CharSets/Test:   `charsets/charser`-wbasset   Good
CharSets/Test:   `charsets/charser`-charsetn   Good
CharSets/Test:   `charsets/charser`-wcharsetn   Good
CharSets/Test:   `charsets/charser`-trisetc   Good
CharSets/Test:   `charsets/mcs`-` `   Good
CharSets/Test:   `charsets/mcs`-basset   Good
CharSets/Test:   `charsets/mcs`-wbasset   Good
CharSets/Test:   `charsets/mcs`-charsetn   Good
CharSets/Test:   `charsets/mcs`-wcharsetn   Good
CharSets/Test:   `charsets/mcs`-trisetc   Good
CharSets/Test:   `charsets/ecs`-` `   Good
CharSets/Test:   `charsets/ecs`-basset   Good
CharSets/Test:   `charsets/ecs`-wbasset   Good
CharSets/Test:   `charsets/ecs`-charsetn   Good
CharSets/Test:   `charsets/ecs`-wcharsetn   Good
CharSets/Test:   `charsets/ecs`-trisetc   Good
CharSets/Test:   `charsets/mecs`-` `   Good
CharSets/Test:   `charsets/mecs`-basset   Good
CharSets/Test:   `charsets/mecs`-wbasset   Good
CharSets/Test:   `charsets/mecs`-charsetn   Good
CharSets/Test:   `charsets/mecs`-wcharsetn   Good
CharSets/Test:   `charsets/mecs`-trisetc   Good
CharSets/Test:   `charsets/triser`-` `   Good
CharSets/Test:   `charsets/csolve`-` `   Good
Warning: be sure the ascending set is irreducible
Warning: be sure the ascending set is irreducible
CharSets/Test:   `charsets/ics`-` `   Good
CharSets/Test:   `charsets/ics`-basset   Good
CharSets/Test:   `charsets/ics`-charsetn   Good
CharSets/Test:   `charsets/ics`-trisetc   Good
Warning: be sure the ascending set is irreducible
CharSets/Test:   `charsets/cfactor`-` `   Good
Warning: factorization over algebraic field required for ics
Warning: factorization over algebraic field required for ics
Warning: factorization over algebraic field required for ics
CharSets/Test:   `charsets/qics`-` `   Good
CharSets/Test:   `charsets/qics`-basset   Good
Warning: factorization over algebraic field required for ics
CharSets/Test:   `charsets/qics`-wbasset   Good
Warning: factorization over algebraic field required for ics
Warning: factorization over algebraic field required for ics
Warning: factorization over algebraic field required for ics
CharSets/Test:   `charsets/qics`-charsetn   Good
Warning: factorization over algebraic field required for ics
Warning: factorization over algebraic field required for ics
CharSets/Test:   `charsets/qics`-wcharsetn   Good
Warning: factorization over algebraic field required for ics
CharSets/Test:   `charsets/qics`-trisetc   Good
CharSets/Test:   `charsets/eics`-` `   Good
CharSets/Test:   `charsets/eics`-basset   Good
CharSets/Test:   `charsets/eics`-charsetn   Good
CharSets/Test:   `charsets/eics`-trisetc   Good
CharSets/Test:   `charsets/ivd`-` `   Good
CharSets/Test:   `charsets/ivd`-basset   Good
CharSets/Test:   `charsets/ivd`-charsetn   Good
CharSets/Test:   `charsets/ivd`-trisetc   Good

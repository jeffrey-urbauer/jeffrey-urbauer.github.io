See ?share and ?share,contents for information about the share library
Share Library:  SF
Author: Stembridge, John.
Description:  A package of routines for manipulating symmetric functions.
The package can express the symmetric functions in the bases
(1) the monomial symmetric functions
(2) the elementary symmetric functions
(3) the complete homogeneous symmetric functions
(4) the power sum symmetric functions
(5) the Schur functions
Warning, new definition for conjugate
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay

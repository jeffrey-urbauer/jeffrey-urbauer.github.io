See ?share and ?share,contents for information about the share library
Share Library:  partials
Author: Cheb-Terrab, Edgardo S..
Description:  procedures for partial and functional derivatives
_______________________________________________________________
`Testing procedures Intc, Int2c, Int3c and Int4c.`
_______________________________________________________________

`Example 1) :   OK`

`Example 2) :   OK`

`Example 3) :   OK`

`Example 4) :   OK`
_______________________________________________________________
`Testing procedure Value.`
_______________________________________________________________

`Example 1) :   OK`

`Example 2) :   OK`

`Example 3) :   OK`

`Example 4) :   OK`

`Example 5) :   OK`

`Example 6) :   OK`

`Example 7) :   OK`

`Example 8) :   OK`

`Example 9) :   OK`

`Example 10) :   OK`

`Example 11) :   OK`

`Example 12) :   OK`

`Example 13) :   OK`

`Example 14) :   OK`

`Example 15) :   OK`

`Example 16) :   OK`
_______________________________________________________________
`Testing procedure evalDi.`
_______________________________________________________________

`Example 1) :   OK`

`Example 2) :   OK`

`Example 3) :   OK`

`Example 4) :   OK`

`Example 5) :   OK`

`Example 6) :   OK`

`Example 7) :   OK`

`Example 8) :   OK`

`Example 9) :   OK`

`Example 10) :   OK`

`Example 11) :   OK`

`Example 12) :   OK`

`Example 13) :   OK`
_______________________________________________________________
`Testing procedure fdiff.`
_______________________________________________________________

`Example 1) :   OK`

`Example 2) :   OK`

`Example 3) :   OK`

`Example 4) :   OK`

`Example 5) :   OK`

`Example 6) :   OK`

`Example 7) :   OK`

`Example 8) :   OK`

`Example 9) :   OK`

`Example 10) :   OK`

`Example 11) :   OK`

`Example 12) :   OK`

`Example 13) :   OK`

`Example 14) :   OK`
_______________________________________________________________
`Testing procedure odiff.`
_______________________________________________________________

`Example 1) :   OK`

`Example 2) :   OK`

`Example 3) :   OK`

`Example 4) :   OK`

`Example 5) :   OK`

`Example 6) :   OK`

`Example 7) :   OK`

`Example 8) :   OK`

`Example 9) :   OK`

`Example 10) :   OK`

`Example 11) :   OK`

`Example 12) :   OK`

`Example 13) :   OK`

`Example 14) :   OK`

`Example 15) :   OK`
_______________________________________________________________
`Testing procedure parameters.`
_______________________________________________________________

`Example 1) :   OK`

`Example 2) :   OK`

`Example 3) :   OK`

`Example 4) :   OK`

`Example 5) :   OK`
_______________________________________________________________
`Testing procedure pdiff.`
_______________________________________________________________

`Example 1) :   OK`

`Example 2) :   OK`

`Example 3) :   OK`

`Example 4) :   OK`

`Example 5) :   OK`

`Example 6) :   OK`

`Example 7) :   OK`

`Example 8) :   OK`

`Example 9) :   OK`

`Example 10) :   OK`

`Example 11) :   OK`

`Example 12) :   OK`

`Example 13) :   OK`

`Example 14) :   OK`

`Example 15) :   OK`

`Example 16) :   OK`

`Example 17) :   OK`

`Example 18) :   OK`

`Example 19) :   OK`

`Example 20) :   OK`

`Example 21) :   OK`

`Example 22) :   OK`

`Example 23) :   OK`

`Example 24) :   OK`

`Example 25) :   OK`

`Example 26) :   OK`

`Example 27) :   OK`

`Example 28) :   OK`

`Example 29) :   OK`

`Example 30) :   OK`

`Example 31) :   OK`

`Example 32) :   OK`

`Example 33) :   OK`

`Example 34) :   OK`

`Example 35) :   OK`

`Example 36) :   OK`

`Example 37) :   OK`

`Example 38) :   OK`

`Example 39) :   OK`

`Example 40) :   OK`

`Example 41) :   OK`

`Example 42) :   OK`

`Example 43) :   OK`

`Example 44) :   OK`

`Example 45) :   OK`

`Example 46) :   OK`
_______________________________________________________________
`Testing procedure seldiff.`
_______________________________________________________________

`Example 1) :   OK`

`Example 2) :   OK`

`Example 3) :   OK`

`Example 4) :   OK`

`Example 5) :   OK`

`Example 6) :   OK`

`Example 7) :   OK`

`Example 8) :   OK`
_______________________________________________________________
`Testing procedures useD and usediff.`
_______________________________________________________________

`Example 1) :   OK`

`Example 2) :   OK`

`Example 3) :   OK`

`Example 4) :   OK`

`Example 5) :   OK`

`Example 6) :   OK`

`Example 7) :   OK`

`Example 8) :   OK`

`Example 9) :   OK`

`Example 10) :   OK`

`Example 11) :   OK`

`Example 12) :   OK`

`Example 13) :   OK`

`Example 14) :   OK`

`Example 15) :   OK`
_______________________________________________________________
`Testing procedure usepdiff.`
_______________________________________________________________

`Example 1) :   OK`

`Example 2) :   OK`

`Example 3) :   OK`

`Example 4) :   OK`

`Example 5) :   OK`

`Example 6) :   OK`

`Example 7) :   OK`

`Example 8) :   OK`
_______________________________________________________________
`Total number of examples: 144`
`Time consumed by a 486 DX-33 for processing this test:  around 60 seconds.`

See ?share and ?share,contents for information about the share library
Share Library:  GB
Authors: Pirklbauer, Andreas, Gruntz, Dominik.
Description:  Implementation of Buchberger's Algorithm for computing Grobner bases over finite fields
ok
ok
ok
ok
ok
ok
ok
ok

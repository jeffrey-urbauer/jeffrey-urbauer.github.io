See ?share and ?share,contents for information about the share library
Share Library:  sdiff
Author: Pindor, Andrzej.
Description:  procedure for differentiating expressions thatcontain sums with indexed variables
OK
OK
OK
OK
OK
OK
OK

See ?share and ?share,contents for information about the share library
Share Library:  spectral
Authors: Goyal, Rohit, Zaven, Karian.
Description:  code tests how good a linear congruential random number generator is
okay
okay
okay

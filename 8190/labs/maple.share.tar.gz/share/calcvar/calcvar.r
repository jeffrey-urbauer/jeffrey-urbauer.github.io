See ?share and ?share,contents for information about the share library
Share Library:  calcvar
Author: Corless, Robert.
Description:  routines to help the user solve certain classes of problems for the calculus of variations
Warning, new definition for depends
ok
ok
ok
ok
ok
ok
ok
ok

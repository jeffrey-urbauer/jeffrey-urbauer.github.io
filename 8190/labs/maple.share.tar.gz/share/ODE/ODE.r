See ?share and ?share,contents for information about the share library
Share Library:  ODE
Author: Daniel Schwalbe.
Description:  package for solving ODE's numerically and plottingtheir solutions
Warning, `res` is implicitly declared local
`solution not found for`, [2, 0], `division by zero`
`solution not found for`, [2, 0], `division by zero`
`solution not found for`, [1, -1], `division by zero`
`solution not found for`, [1, -1], `division by zero`
`solution not found for`, [0, -2], `division by zero`
`solution not found for`, [0, -2], `division by zero`
1, "-- okay"
2, "-- okay"
3, "-- okay"
4, "-- okay"
6, "-- okay"
7, "-- okay"
8, "-- okay"
15, "-- okay"
16, "-- okay"
19, "-- okay"
21, "-- okay"
22, "-- okay"
23, "-- okay"
25, "-- okay"
26, "-- okay"
27, "-- okay"
28, "-- okay"
31, "-- okay"
32, "-- okay"
34, "-- okay"
35, "-- okay"
36, "-- okay"
39, "-- okay"
40, "-- okay"
41, "-- okay"

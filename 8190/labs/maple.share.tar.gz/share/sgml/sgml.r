See ?share and ?share,contents for information about the share library
Share Library:  sgml
Author: Wolfgang Frings.
Description:  This is a Maple package based on Maple's latex command
for converting Maple expressions into the ISO standard
SGML (Standard Generalized Markup Language). The produced
code is suitable for SGML text processing systems which
use the international mathematics standard as published by
the Association of American Publishers.
<display-equation><fd><fl>
x<sup>2</sup>+y<sup>2</sup>=z<sup>2</sup>
</fl></fd></display-equation>
<inline-equation><f>
x<sup>2</sup>+y<sup>2</sup>=z<sup>2</sup>
</f></inline-equation>
<display-equation><fd><fl>
<in align="c"></in><hsp sp="0.167"><fen lp="par"> x<sup>2</sup>+1
<rp post="par"></fen><sup>-1</sup><hsp sp="0.167">dx=<rf>arctan</rf>
<fen lp="par">x<rp post="par"></fen>
</fl></fd></display-equation>
<display-equation><fd><fl>
-3<hsp sp="0.265"><rad><rcd>-1</rcd></rad><g>p</g>
</fl></fd></display-equation>
<display-equation><fd><fl>
<it>Total_profit</it><hsp sp="0.265"><it>Rate</it>
</fl></fd></display-equation>
<display-equation><fd><fl>
<fr><nu><g>G</g><fen lp="par">x<rp post="par"></fen></nu><de><g>g</g>
</de></fr>+<fr><nu><g>y</g></nu><de><g>b</g></de></fr>
</fl></fd></display-equation>
<display-equation><fd><fl>
<in align="c"></in><hsp sp="0.167">e<sup>x</sup><hsp sp="0.167">dx
</fl></fd></display-equation>
<display-equation><fd><fl>
<lim align="c"><op><rf>lim</rf></op><ll>x&rarr;0<sup>-</sup></ll>3+y
<fen lp="par">x<rp post="par"></fen></lim>
</fl></fd></display-equation>

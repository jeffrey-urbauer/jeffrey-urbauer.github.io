See ?share and ?share,contents for information about the share library
Share Library:  pffge
Author: Monagan, Michael.
Description:  Primitive fraction-free Gaussian elimination for a rectangular matrix of multivariate polynomials.  After a row operation, the gcd of the polynomials in the row is divided out.  This minimizes the size of the intermediate polynomials.
okay
okay
okay
okay
okay
okay

See ?share and ?share,contents for information about the share library
Share Library:  surfaces
Author: Murdoch, Tim.
Description:  procedures to calculate basic differential-geometric quantities of parametric surfaces in space.  The procedures calculate first and second fundamental forms, the metric determinant, Gauss curvature and the Mean curvature
`g11 okay`
`g12 okay`
`g21 okay`
`g22 okay`
`metricdet okay`
`unitnormal okay`
`b11 okay`
`b12 okay`
`b21 okay`
`b22 okay`
`Gausscurv okay`
`Meancurv okay`

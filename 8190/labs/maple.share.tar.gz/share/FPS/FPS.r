See ?share and ?share,contents for information about the share library
Share Library:  FPS
Author: Gruntz, Dominik.
Description:  FPS function attempts to find a formal power seriesexpansion for a function in terms of a formula for the coefficients
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok

See ?share and ?share,contents for information about the share library
Share Library:  fft
Author: Earl, Stephen.
Description:  Maple routines for the calculation of the Fast Fourier Transform.  Routine even works for complex sequences
okay
okay
okay
okay
okay
okay

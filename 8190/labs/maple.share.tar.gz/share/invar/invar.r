See ?share and ?share,contents for information about the share library
Share Library:  invar
Author: Kemper, Gregor.
Description:  The invar package is a package of routines mainly for computing the invariant ring of permutation groups or finite linear groups over Q or an algebraic number field.
okay
okay
okay
`Warning: _known is overwritten!`
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay

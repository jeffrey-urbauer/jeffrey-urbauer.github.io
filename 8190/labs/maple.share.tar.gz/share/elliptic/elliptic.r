See ?share and ?share,contents for information about the share library
Share Library:  elliptic
Author: Eric Von York.
Description:  Determines the order of the group of points on a non-singular elliptic curve y^2 = x^3+A*x+B over a finite field Z mod p
okay
okay

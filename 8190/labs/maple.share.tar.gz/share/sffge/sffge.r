See ?share and ?share,contents for information about the share library
Share Library:  sffge
Authors: Berchtold, Igor, Monagan, Michael.
Description:  Performs Bareiss' fraction free Gaussianelimination algorithm on a rectangular matrix of polynomial entries andreturns the reduces matrix (in upper triangular form) and optionally therank and determinant.  This routine has the same functionalityas the library routine linalg[ffgausselim] but is usinga variation of Nguyen and Saunders algorithm which is suitedto sparse matrices.
okay
okay
okay
okay
okay
okay

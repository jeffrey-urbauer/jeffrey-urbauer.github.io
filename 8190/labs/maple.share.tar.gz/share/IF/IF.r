See ?share and ?share,contents for information about the share library
Share Library:  IF
Author: Cucker, Felipe.
Description:  Package of routines for computing with real algebraicnumbers, signs of the roots of polynomials, solvingsystems of equations, and computing a cylindrical algebraicdecomposition of a plane algebraic curve.
okay
okay
okay
okay
`the projection direction is`, y
okay
okay
okay
okay
okay

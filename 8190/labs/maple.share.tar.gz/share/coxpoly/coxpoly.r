See ?share and ?share,contents for information about the share library
Share Library:  coxpoly
Author: Boldt, Axel.
Description:  Computes the characteristic polynomial of the coxeter matrix
of certain symbolically given quiver classes.
okay
okay
okay
okay
okay
okay
okay

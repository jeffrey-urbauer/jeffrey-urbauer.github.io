See ?share and ?share,contents for information about the share library
Share Library:  rubik3
Author: Joyner, David.
Description:  The rubik3 share package contains routines
which simulate the moves of the 3x3x3 Rubik's cube in MAPLE.
(It does not solve it.)
ok
ok
ok

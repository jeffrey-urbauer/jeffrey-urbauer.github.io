See ?share and ?share,contents for information about the share library
Share Library:  fit
Author: Gruntz, Dominik.
Description:  function returns the least squares fit of a curve to a given set of data points
okay
okay
okay
okay
okay

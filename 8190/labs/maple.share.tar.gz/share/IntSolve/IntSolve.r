See ?share and ?share,contents for information about the share library
Share Library:  IntSolve
Authors: Ye, Honglin, Corless, Robert M..
Description:  Version 1 of an integral equation solver.
ok
ok
ok
ok
ok
ok
ok

See ?share and ?share,contents for information about the share library
Share Library:  fields
Author: Gregor Kemper.
Description:  Let N be a field extension of L, a field extension of K,such that N is finitely generated over K.This package uses Grobner basis methods to calculate the transcendence degree of N|L and the degree [N:L] if the field extension is algebraic, and related questions.  The implementation works for K = Q or K = Q(alpha) a single algebraic extension of Q.
okay
okay
okay
okay
okay
okay
okay
okay
okay

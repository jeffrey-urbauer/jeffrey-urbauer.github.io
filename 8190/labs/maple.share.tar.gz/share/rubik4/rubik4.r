See ?share and ?share,contents for information about the share library
Share Library:  rubik4
Author: Joyner, David.
Description:  The rubik4 share package contains routines to simulate the moves of the 4x4x4 Rubik's cube.
ok
ok
ok

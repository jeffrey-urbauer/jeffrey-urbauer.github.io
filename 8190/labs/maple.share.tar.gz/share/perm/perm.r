See ?share and ?share,contents for information about the share library
Share Library:  perm
Author: Chiricota, Yves.
Description:  A package of routines for computing with permutation groups, including routines for computing orbits, subgroups, testing for conjugacy. There are also procedures used to represent and manipulate combinatorial structures.
* The table "tabsg" is not defined *
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay

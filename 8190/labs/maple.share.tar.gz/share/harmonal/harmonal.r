See ?share and ?share,contents for information about the share library
Share Library:  harmonal
Author: Rough, Alistair.
Description:  Routine to calculate the harmonic content of a 3-phase, thyristor bridge for a firing angle y (degrees) and a notionalfrequency of 1 Hz
a0 := 2*(1+cos(1/180*Pi*y))/Pi
a0 := 2*(1+cos(1/180*Pi*y))/Pi
a0 := 2/Pi+2/Pi*cos(1/180*Pi*y)
ax := (-1-cos(1/180*Pi*y)*cos(1/180*Pi*x*y)*cos(x*Pi)-cos(1/180*Pi*y)*sin(1/180
*Pi*x*y)*sin(x*Pi)-x*sin(1/180*Pi*y)*sin(1/180*Pi*x*y)*cos(x*Pi)+x*sin(1/180*Pi
*y)*cos(1/180*Pi*x*y)*sin(x*Pi))/Pi/(1+x)/(-1+x)-(cos(x*Pi)+cos(1/180*Pi*y)*cos
(1/180*Pi*x*y)+x*sin(1/180*Pi*y)*sin(1/180*Pi*x*y))/Pi/(1+x)/(-1+x)
ax := -1/Pi/(1+x)/(-1+x)-1/Pi/(1+x)/(-1+x)*cos(1/180*Pi*y)*cos(1/180*Pi*x*y)*
cos(x*Pi)-1/Pi/(1+x)/(-1+x)*cos(1/180*Pi*y)*sin(1/180*Pi*x*y)*sin(x*Pi)-1/Pi/(1
+x)/(-1+x)*x*sin(1/180*Pi*y)*sin(1/180*Pi*x*y)*cos(x*Pi)+1/Pi/(1+x)/(-1+x)*x*
sin(1/180*Pi*y)*cos(1/180*Pi*x*y)*sin(x*Pi)-1/Pi/(1+x)/(-1+x)*cos(x*Pi)-1/Pi/(1
+x)/(-1+x)*cos(1/180*Pi*y)*cos(1/180*Pi*x*y)-1/Pi/(1+x)/(-1+x)*x*sin(1/180*Pi*y
)*sin(1/180*Pi*x*y)
ax := -1/Pi/(1+x)/(-1+x)-1/Pi/(1+x)/(-1+x)*cos(1/180*Pi*y)*cos(1/180*Pi*x*y)*(-\
1)^x-1/Pi/(1+x)/(-1+x)*x*sin(1/180*Pi*y)*sin(1/180*Pi*x*y)*(-1)^x-1/Pi/(1+x)/(-\
1+x)*(-1)^x-1/Pi/(1+x)/(-1+x)*cos(1/180*Pi*y)*cos(1/180*Pi*x*y)-1/Pi/(1+x)/(-1+
x)*x*sin(1/180*Pi*y)*sin(1/180*Pi*x*y)
ax := -(1+cos(1/180*Pi*y)*cos(1/180*Pi*x*y)*(-1)^x+x*sin(1/180*Pi*y)*sin(1/180*
Pi*x*y)*(-1)^x+(-1)^x+cos(1/180*Pi*y)*cos(1/180*Pi*x*y)+x*sin(1/180*Pi*y)*sin(1
/180*Pi*x*y))/Pi/(1+x)/(-1+x)
ax := -((-1)^x+1)*(cos(1/180*Pi*y)*cos(1/180*Pi*x*y)+x*sin(1/180*Pi*y)*sin(1/
180*Pi*x*y)+1)/Pi/(1+x)/(-1+x)
bx := (-cos(1/180*Pi*y)*sin(1/180*Pi*x*y)*cos(x*Pi)+cos(1/180*Pi*y)*cos(1/180*
Pi*x*y)*sin(x*Pi)+x*sin(1/180*Pi*y)*cos(1/180*Pi*x*y)*cos(x*Pi)+x*sin(1/180*Pi*
y)*sin(1/180*Pi*x*y)*sin(x*Pi))/Pi/(-1+x)/(1+x)+(-sin(x*Pi)-cos(1/180*Pi*y)*sin
(1/180*Pi*x*y)+x*sin(1/180*Pi*y)*cos(1/180*Pi*x*y))/Pi/(-1+x)/(1+x)
bx := -1/Pi/(1+x)/(-1+x)*cos(1/180*Pi*y)*sin(1/180*Pi*x*y)*cos(x*Pi)+1/Pi/(1+x)
/(-1+x)*cos(1/180*Pi*y)*cos(1/180*Pi*x*y)*sin(x*Pi)+1/Pi/(1+x)/(-1+x)*x*sin(1/
180*Pi*y)*cos(1/180*Pi*x*y)*cos(x*Pi)+1/Pi/(1+x)/(-1+x)*x*sin(1/180*Pi*y)*sin(1
/180*Pi*x*y)*sin(x*Pi)-1/Pi/(1+x)/(-1+x)*sin(x*Pi)-1/Pi/(1+x)/(-1+x)*cos(1/180*
Pi*y)*sin(1/180*Pi*x*y)+1/Pi/(1+x)/(-1+x)*x*sin(1/180*Pi*y)*cos(1/180*Pi*x*y)
bx := -1/Pi/(1+x)/(-1+x)*cos(1/180*Pi*y)*sin(1/180*Pi*x*y)*(-1)^x+1/Pi/(1+x)/(-\
1+x)*x*sin(1/180*Pi*y)*cos(1/180*Pi*x*y)*(-1)^x-1/Pi/(1+x)/(-1+x)*cos(1/180*Pi*
y)*sin(1/180*Pi*x*y)+1/Pi/(1+x)/(-1+x)*x*sin(1/180*Pi*y)*cos(1/180*Pi*x*y)
bx := (-cos(1/180*Pi*y)*sin(1/180*Pi*x*y)*(-1)^x+x*sin(1/180*Pi*y)*cos(1/180*Pi
*x*y)*(-1)^x-cos(1/180*Pi*y)*sin(1/180*Pi*x*y)+x*sin(1/180*Pi*y)*cos(1/180*Pi*x
*y))/Pi/(1+x)/(-1+x)
bx := ((-1)^x+1)*(-cos(1/180*Pi*y)*sin(1/180*Pi*x*y)+x*sin(1/180*Pi*y)*cos(1/
180*Pi*x*y))/Pi/(1+x)/(-1+x)
a1 := 0
b1 := 0
rx := (((-1)^x+1)^2*(cos(1/180*Pi*y)*cos(1/180*Pi*x*y)+x*sin(1/180*Pi*y)*sin(1/
180*Pi*x*y)+1)^2/Pi^2/(1+x)^2/(-1+x)^2+((-1)^x+1)^2*(-cos(1/180*Pi*y)*sin(1/180
*Pi*x*y)+x*sin(1/180*Pi*y)*cos(1/180*Pi*x*y))^2/Pi^2/(1+x)^2/(-1+x)^2)^(1/2)
y := 'y'

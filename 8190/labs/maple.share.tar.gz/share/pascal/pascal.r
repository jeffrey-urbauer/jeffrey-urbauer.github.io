See ?share and ?share,contents for information about the share library
Share Library:  pascal
Author: Monagan, Michael.
Description:  Create an n by n Pascal matrix.A family of matrices with nice properties -- realeigenvalues, determinant = 1.
okay

See ?share and ?share,contents for information about the share library
Share Library:  MatPade
Author: Labahn, George.
Description:  A set of functions to compute matrix-type Pade approximants.  Examples of such approximants include Hermite Pade, Simultaneous Pade, right and left matrix Pade approximants.
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay

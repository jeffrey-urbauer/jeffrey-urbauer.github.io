See ?share and ?share,contents for information about the share library
Share Library:  macsubs
Author: Broman, Vincent.
Description:  Replaces functions in an expression with Maclaurin series (a formal Sum).  No checking for convergence is made.
okay
okay
okay
okay
okay
okay

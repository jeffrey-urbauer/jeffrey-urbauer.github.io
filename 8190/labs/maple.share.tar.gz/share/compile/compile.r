See ?share and ?share,contents for information about the share library
Share Library:  compile
Author: Monagan, M.B..
Description:  Translate a Maple Procedure into a C functionand compile it.  The result is a Maple procedurewhich invokes the compiled C code.
compile:   The compile command is presently only supported under Unix.
compile:   It will not run on a Macintosh or PC computer.
compile:   Translating Maple code to C
compile:   Compiling and linking ./ifs.c and ./mainifs.c .
okay
compile:   Translating Maple code to C
compile:   Compiling and linking ./ifs.c and ./mainifs.c .
okay
compile:   Translating Maple code to C
compile:   Compiling and linking ./ifs.c and ./mainifs.c .
okay
compile:   Translating Maple code to C
compile:   Compiling and linking ./ifs.c and ./mainifs.c .
okay
compile:   Translating Maple code to C
compile:   Compiling and linking ./ifs.c and ./mainifs.c .
okay
compile:   Translating Maple code to C
compile:   Compiling and linking ./f.c and ./mainf.c .
okay
compile:   Translating Maple code to C
compile:   Compiling and linking ./g.c and ./maing.c .
okay
okay
compile:   Translating Maple code to C
compile:   Compiling and linking ./m.c and ./mainm.c .
okay
compile:   Translating Maple code to C
compile:   Compiling and linking ./m.c and ./mainm.c .
okay

Can't apply the reverse mode.
Trying with the forward mode...
compile:   Translating Maple code to C
compile:   Compiling and linking ./F.c and ./mainF.c .
okay
compile:   Translating Maple code to C
compile:   Compiling and linking ./f.c and ./mainf.c .
okay

Can't apply the reverse mode.
Trying with the forward mode...
compile:   Translating Maple code to C
compile:   Compiling and linking ./F.c and ./mainF.c .
okay
compile:   Translating Maple code to C
compile:   Compiling and linking ./J.c and ./mainJ.c .
okay
compile:   Translating Maple code to C
compile:   Compiling and linking ./e.c and ./maine.c .
okay
compile:   Translating Maple code to C
compile:   Compiling and linking ./g3.c and ./maing3.c .
okay
okay

See ?share and ?share,contents for information about the share library
Share Library:  orbitals
Author: Homier, Herbert H. H..
Description:  procedures for the computation of real and complex spherical solid and surface harmonics
[ComplexSolidHarmonic, ComplexSurfaceHarmonic, RealSurfaceHarmonic]
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay

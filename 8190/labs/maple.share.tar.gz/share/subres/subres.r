See ?share and ?share,contents for information about the share library
Share Library:  subres
Author: Labahn, George.
Description:  Given two polynomials a and b in x the function subres(a,b,x) computes the subresultant polynomial remainder sequence.
okay
okay
okay
okay
okay
okay

See ?share and ?share,contents for information about the share library
Share Library:  hint
Author: Bertrand, Laurent.
Description:  routine to compute indefinite hyperelliptic integrals
okay
okay
okay
okay
okay

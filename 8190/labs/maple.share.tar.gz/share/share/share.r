See ?share and ?share,contents for information about the share library
ok

# file maple0

with(linalg):

vec:= array( [x,y] );
with(linalg,vector):                           vvec:= vector( [x,y] );
A:= array( 1..2,1..2,[ [a11,a12], [a21,a22] ]);
mat:=array([eval(vec),eval(vec)]):            # NOT a matrix
quit

with(linalg):
A:= matrix( 2,2,[ [a11,a12], [a21,a22] ]);
A:= matrix([ [a11,a12], [a21,a22] ]):
A:= matrix( 2,2,[a11,a12, a21,a22] ):
A;
B:= swaprow( A,1,2 );
evalm( A+A ):
C:= %;
A2:= evalm( 2*A );              #  Note that D  is a reserved word in Maple
equal( C,A2 );
evalm( ca*A+cb*B );
evalm( A &* A );
equal( evalm(A^2), % );
inverse(A);
evalm( A &* % );
Id:= diag(1,1);  # The symbol I cannot be used as it is reserved for sqrt(-1)
# This can be generalised for any  n by n  matrix (Here n is 2):
n:=2:              diag( 1$n ):        # 1$n is the sequence 1 .. 1 (n times)
equal( %,Id);
array(1..n,1..n,identity):        # This can be done outside linalg
equal( %,Id);
band( [1],n ):                            equal( %,Id);
C:= evalm( A+B );
inverse(C);
# This error is because the two rows of  C  are the same.
Atr:= transpose(A);

n:=3:                                     A.n:= band([-1,2,-1],n);
toeplitz([2,-1,0]):                            equal( %,A3);
H.n:=hilbert(n);
vandermonde([11,12,13]);
quit

# One can set up general matrices in the form given above:
with(linalg):
f:= proc(i,j)            a.i.j            end:
A:= matrix(2,3,f); 

col(A,1);
submatrix( A,1..2,[1,3] );
quit

with(linalg):
A:= band( [x,x^2+2*x,-x],3 );
B:= subs( x=a+b,op(A) ):                            Bs:= map( simplify,B );
Be:= map( expand,B );
# The entries in Be are, in this case, the same as in Bs.
#
subs( a=3/10,b=1/10,op(B) ):
Bf:= map( evalf,% );
quit

with(linalg):
# Maple can deal with matrices with general entries.  Set one up as before.
f:= proc(i,j)            a.i.j            end:
A:= matrix(2,2,f); 
type(A,matrix);
t:= trace(A);                                               d:= det(A);
# The following yields a formula which is true for any  2 by 2  matrix
map( simplify, evalm( A^2 - t*A + d) );
quit


See ?share and ?share,contents for information about the share library
Share Library:  Hurwitz
Author: Corless, Robert.
Description:  Code to test if a polynomial is of Hurwitz type, 
i.e., the real part of its roots is negative
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok

See ?share and ?share,contents for information about the share library
Share Library:  msubres
Author: Labahn, George.
Description:  Computes the subresultant polynomial remainder sequence of two polynomials over the integers modulo m
okay
okay
okay
okay
okay

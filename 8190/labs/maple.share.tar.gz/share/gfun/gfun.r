See ?share and ?share,contents for information about the share library
Share Library:  gfun
Authors: Salvy, Bruno, Zimmerman, Paul.
Description:  package for the manipulation and discovery ofgenerating functions
`Testing rectoproc`
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
`Testing diffeqtorec`
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
`Testing rectodiffeq`
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
`Testing diffeq+diffeq, diffeq*diffeq, cauchyproduct, poltodiffeq`
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
`Testing rec+rec, rec*rec, cauchyproduct, poltorec`
ok
ok
ok
ok
ok
ok
ok
ok
ok
`Testing borel, invborel`
ok
ok
ok
ok
ok
y(z)-z, z-y(z)
ok
ok
`Testing algeqtodiffeq`
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
`Testing algebraicsubs`
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
`Testing algeqtoseries`
ok
ok
ok
ok
ok
`Testing algfuntoalgeq`
ok
ok
ok
ok
`Testing holexprtodiffeq`
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
ok
`Testing diffeqtohomdiffeq and rectohomrec`
ok
ok
ok
ok
ok
`Testing ratpolytocoeff`
ok
`Testing listtoseries`
ok
`Testing seriestolist`
ok
`Testing listtohypergeom`
ok
`Testing pade2`
ok
ok
ok
`Testing listtoratpoly`
ok
`Testing listtorec`
ok
ok
ok
`Testing listtodiffeq`
ok
`Testing seriestodiffeq`
ok
`Testing listtoalgeq`
ok
`Testing seriestoalgeq`
ok
`Testing guesseqn`
ok
`Testing guessgf`
ok
ok
ok
ok
ok
ok
ok

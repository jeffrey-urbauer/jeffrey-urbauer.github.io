See ?share and ?share,contents for information about the share library
Share Library:  Grassmann
Author: E.S. Cheb-Terrab.
Description:  For products and derivatives of anticommutative and noncommutative objects.
_______________________________________________________________
`Testing the types subroutines ac_var, nc_var, commutative`, 
`and noncommutative`
_______________________________________________________________

`Example 1) :   OK`

`Example 2) :   OK`

`Example 3) :   OK`

`Example 4) :   OK`

`Example 5) :   OK`
_______________________________________________________________
`Testing procedure parity.`
_______________________________________________________________

`Example 1) :   OK`

`Example 2) :   OK`

`Example 3) :   OK`

`Example 4) :   OK`

`Example 5) :   OK`

`Example 6) :   OK`

`Example 7) :   OK`
_______________________________________________________________
`Testing procedure msort.`
_______________________________________________________________

`Example 1) :   OK`

`Example 2) :   OK`

`Example 3) :   OK`

`Example 4) :   OK`

`Example 5) :   OK`
_______________________________________________________________
`Testing procedure mexpand.`
_______________________________________________________________

`Example 1) :   OK`

`Example 2) :   OK`

`Example 3) :   OK`

`Example 4) :   OK`

`Example 5) :   OK`

`Example 6) :   OK`
_______________________________________________________________
`Testing procedure mcheck.`
_______________________________________________________________

`Example 1) :   OK`

`Example 2) :   OK`

`Example 3) :   OK`

`Example 4) :   OK`

`Example 5) :   OK`

`Example 6) :   OK`

`Example 7) :   OK`
_______________________________________________________________
`Testing procedure Tr.`
_______________________________________________________________

`Example 1) :   OK`

`Example 2) :   OK`

`Example 3) :   OK`

`Example 4) :   OK`

`Example 5) :   OK`

`Example 6) :   OK`

`Example 7) :   OK`
_______________________________________________________________
`Testing procedure inv.`
_______________________________________________________________

`Example 1) :   OK`

`Example 2) :   OK`

`Example 3) :   OK`

`Example 4) :   OK`

`Example 5) :   OK`
_______________________________________________________________
`Testing procedure gdiff.`
_______________________________________________________________

`Example 1) :   OK`

`Example 2) :   OK`

`Example 3) :   OK`

`Example 4) :   OK`

`Example 5) :   OK`

`Example 6) :   OK`

`Example 7) :   OK`

`Example 8) :   OK`

`Example 9) :   OK`
_______________________________________________________________
`Testing procedures useD and usegdiff.`
_______________________________________________________________

`Example 1) :   OK`

`Example 2) :   OK`

`Example 3) :   OK`
_______________________________________________________________
`Total number of examples: 54`
`Fail examples: 0`

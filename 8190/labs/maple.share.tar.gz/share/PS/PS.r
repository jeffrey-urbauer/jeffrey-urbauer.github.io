See ?share and ?share,contents for information about the share library
Share Library:  PS
Author: Gruntz, Dominik.
Description:  this power series package is an improved version of the library package powseries for manipulating formal power series
Warning, new definition for `^`
Warning, new definition for add
true
true
true
true
true
true
true
true
true
true
true
true
true
true
true
true
true
true
true
true
true
true
true
true
true
true
true
true
true
true
true
true
true

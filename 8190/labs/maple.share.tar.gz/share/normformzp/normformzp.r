See ?share and ?share,contents for information about the share library
Share Library:  normformzp
Authors: T.M.L. Mulders, A.H.M. Levelt.
Description:  Package for computing normal forms for matrices over the integers modulo p
OK
`End of test of Frobenius`
OK
`End of test of Ratjordan`
OK
`End of test of Jordansymbolic`

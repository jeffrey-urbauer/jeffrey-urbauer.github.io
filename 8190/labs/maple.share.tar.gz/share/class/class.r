See ?share and ?share,contents for information about the share library
Share Library:  class
Author: Johnson, Eugene.
Description:  Rational canonical form for a matrix of rational numbers.  Includes a utility routine HyperCompanion for constructing the hyper companion matrix of a univariate polynomial
okay
okay

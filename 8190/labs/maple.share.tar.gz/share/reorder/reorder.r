See ?share and ?share,contents for information about the share library
Share Library:  reorder
Author: Broman, Vincent.
Description:  Utility routine to reorder the order in which two ormore sums, limits, or integrals appear in an expression.
okay
okay
okay

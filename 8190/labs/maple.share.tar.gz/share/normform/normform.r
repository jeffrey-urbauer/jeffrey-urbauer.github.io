See ?share and ?share,contents for information about the share library
Share Library:  normform
Authors: Mulders, T.M.L., Levelt, A.H.M..
Description:  A package of routines for computing matrix normal forms.  Contains: ismithex, smithex, frobenius, jordan, and ratjordan.  The ismithex and smithex routines compute the Smith normal form over Z and F[x] respectively.  The frobenius, jordan, and ratjordan routines compute the Frobenius, Jordan, and rational Jordan normal forms over a field K.  These routines are typically faster than the routines in the Maple library, more general, and also compute the multiplier matrices.  Example:  F := frobenius(A,K,'P');  computes Frobenius normal form F, and the matrix P such that F = P^(-1) A P
OK
OK
OK
OK
OK
`End of test of frobenius`
OK
OK
OK
OK
OK
`End of test of ratjordan`
OK
OK
OK
OK
OK
`End of test of jordansymbolic`
OK
OK
`End of test of jordan`
OK
OK
`End of test of smithex`
OK
`End of test of ismithex`

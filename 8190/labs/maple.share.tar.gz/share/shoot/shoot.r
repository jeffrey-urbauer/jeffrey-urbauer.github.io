See ?share and ?share,contents for information about the share library
Share Library:  shoot
Author: Meade, Douglas B..
Description:  Meade, D.B., Haran, B.S., and White, R.E., Theshooting technique for the solution of two-point boundary value problems,MapleTech 3(1), 1996, pp. 85-93.
ok
ok
ok
ok
ok
ok

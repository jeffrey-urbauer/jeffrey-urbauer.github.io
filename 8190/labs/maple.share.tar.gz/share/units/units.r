See ?share and ?share,contents for information about the share library
Share Library:  units
Author: Baylis, William E..
Description:  Code that automatically converts expressions to SI units
okay
okay
okay

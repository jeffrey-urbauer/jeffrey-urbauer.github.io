See ?share and ?share,contents for information about the share library
Share Library:  convert_arctanh
Author: Broman, Vincent.
Description:  Rewrite all logarithms and inverse hyperbolic trig functions in an expression in terms of arctanh.
okay
okay
okay

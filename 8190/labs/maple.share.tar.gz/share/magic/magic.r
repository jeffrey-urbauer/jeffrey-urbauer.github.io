See ?share and ?share,contents for information about the share library
Share Library:  magic
Author: Gruntz, Dominik.
Description:  create n by n magic squares
okay
okay
okay
okay

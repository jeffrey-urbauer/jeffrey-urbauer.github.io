See ?share and ?share,contents for information about the share library
Share Library:  ilp
Author: Pathria, Anu.
Description:  an integer linear programming algorithm for maximizing a linear function given a set of linear constraints
true
true
true
true
true
true
true
true
true
true
true
true

See ?share and ?share,contents for information about the share library
Share Library:  rfinterp
Author: Carlos von Achenbach.
Description:  Computes the rational function in x whichinterpolates the given data points x[i], y[i]
okay
okay
okay

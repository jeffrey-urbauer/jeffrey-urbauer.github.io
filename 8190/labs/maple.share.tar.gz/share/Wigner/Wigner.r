See ?share and ?share,contents for information about the share library
Share Library:  Wigner
Author: Dennis Isbister.
Description:  Procedures to calculate the rotation matrix functions and the 3-j and 6-j Wigner coefficients
okay
okay
okay
okay
okay
okay
okay
okay

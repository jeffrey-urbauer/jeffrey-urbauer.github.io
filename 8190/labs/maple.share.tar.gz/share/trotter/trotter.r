See ?share and ?share,contents for information about the share library
Share Library:  trotter
Author: Jeurissen, Ruud.
Description:  Implementation of the Trotter algorithm
okay
okay
okay
okay
okay
okay
okay
okay
okay

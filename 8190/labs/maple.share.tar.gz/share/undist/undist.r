See ?share and ?share,contents for information about the share library
Share Library:  undist
Author: Vincent Broman.
Description:  Factors out of integrands, summands, and limits any factors which are constant with respect to the index.
okay
okay
okay

See ?share and ?share,contents for information about the share library
Share Library:  hankel
Author: Douglas B. Meade.
Description:  implementation of Hankel functions in terms of BesselJ and BesselY
okay
okay
okay
okay
okay
okay
okay
okay

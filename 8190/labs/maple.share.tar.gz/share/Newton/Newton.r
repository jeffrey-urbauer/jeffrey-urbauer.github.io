See ?share and ?share,contents for information about the share library
Share Library:  Newton
Author: Taylor, Ross.
Description:  An implementation of a Newton iteration for solvingnon-linear systems of equations
Warning, new definition for norm
Warning, new definition for trace
x1 = .8, x2 = 5.8
f[1] = 17.28, f[2] = .9283177667*8^(1/3)-1.591681084
x1 = .8594908014, x2 = 4.302139200
f[1] = 2.24712614, f[2] = .9507808175*8^(1/3)-1.925840122
x1 = .9860437649, x2 = 4.015692360
f[1] = .9806744e-1, f[2] = .9953261104*8^(1/3)-1.996080750
x1 = .9998994589, x2 = 4.000079600
f[1] = .43574e-3, f[2] = .9999664852*8^(1/3)-1.999980100
x1 = .9999999960, x2 = 4.000000002
f[1] = .1e-7, f[2] = .9999999987*8^(1/3)-1.999999999
result := [x1 = .9999999998, x2 = 4.000000000]
x1 = 5.8, x2 = 5.8
x1 = 1010.881554, x2 = -1003.616037
x1 = 1495.169224-1212.649605*I, x2 = 495.076939-1221.428387*I
x1 = 351.927888-3159.449867*I, x2 = -1048.343499+2933.652126*I
x1 = -1115.235138-7500.477563*I, x2 = -3197.135700-4109.347761*I
x1 = -9018.623826-8013.840042*I, x2 = 6083.628714+9407.988869*I
x1 = -21524.90596-17597.52984*I, x2 = -18524.25754-4506.870431*I
Error, (in Newton) Maximum number of iterations exceeded
proc (delx) local i, nvars, newstep; if not type(maxstep,numeric) then ERROR(
`Please set global variable named maxstep before using teststep`) fi; nvars :=
linalg[vectdim](delx); newstep := linalg[vector](nvars); for i to nvars do 
newstep[i] := maxchange(delx[i],maxstep) od; evalm(newstep) end
x1 = 5.8, x2 = 5.8
x1 = 5.9, x2 = 5.7
x1 = 6.0, x2 = 5.6
x1 = 6.1, x2 = 5.5
x1 = 6.2, x2 = 5.4
x1 = 6.3, x2 = 5.3
x1 = 6.4, x2 = 5.2
x1 = 6.5, x2 = 5.1
x1 = 6.6, x2 = 5.0
x1 = 6.7, x2 = 4.9
x1 = 6.8, x2 = 4.8
x1 = 6.9, x2 = 4.7
x1 = 7.0, x2 = 4.6
x1 = 7.1, x2 = 4.5
x1 = 7.2, x2 = 4.4
x1 = 7.3, x2 = 4.3
x1 = 7.4, x2 = 4.2
x1 = 7.5, x2 = 4.1
x1 = 7.6, x2 = 4.0
x1 = 7.7, x2 = 3.9
x1 = 7.8, x2 = 3.8
x1 = 7.7, x2 = 3.7
x1 = 7.6, x2 = 3.6
x1 = 7.5, x2 = 3.5
x1 = 7.4, x2 = 3.4
x1 = 7.3, x2 = 3.3
x1 = 7.2, x2 = 3.2
Error, (in Newton) Maximum number of iterations exceeded
x1 = 5.8, x2 = 5.8
x1 = 5.9, x2 = 5.7
x1 = 6.0, x2 = 5.6
x1 = 6.1, x2 = 5.5
x1 = 6.2, x2 = 5.4
x1 = 6.3, x2 = 5.3
x1 = 6.4, x2 = 5.2
x1 = 6.5, x2 = 5.1
x1 = 6.6, x2 = 5.0
x1 = 6.7, x2 = 4.9
x1 = 6.8, x2 = 4.8
x1 = 6.9, x2 = 4.7
x1 = 7.0, x2 = 4.6
x1 = 7.1, x2 = 4.5
x1 = 7.2, x2 = 4.4
x1 = 7.3, x2 = 4.3
x1 = 7.4, x2 = 4.2
x1 = 7.5, x2 = 4.1
x1 = 7.6, x2 = 4.0
x1 = 7.7, x2 = 3.9
x1 = 7.8, x2 = 3.8
x1 = 7.7, x2 = 3.7
x1 = 7.6, x2 = 3.6
x1 = 7.5, x2 = 3.5
x1 = 7.4, x2 = 3.4
x1 = 7.3, x2 = 3.3
x1 = 7.2, x2 = 3.2
x1 = 7.1, x2 = 3.1
x1 = 7.0, x2 = 3.0
x1 = 6.9, x2 = 2.9
x1 = 6.8, x2 = 2.8
x1 = 6.7, x2 = 2.7
x1 = 6.6, x2 = 2.6
x1 = 6.5, x2 = 2.5
x1 = 6.4, x2 = 2.4
x1 = 6.3, x2 = 2.3
x1 = 6.2, x2 = 2.2
x1 = 6.1, x2 = 2.1
x1 = 6.0, x2 = 2.0
x1 = 5.9, x2 = 1.9
x1 = 5.8, x2 = 1.8
x1 = 5.7, x2 = 1.7
x1 = 5.6, x2 = 1.6
x1 = 5.5, x2 = 1.5
x1 = 5.4, x2 = 1.4
x1 = 5.3, x2 = 1.3
x1 = 5.2, x2 = 1.2
x1 = 5.1, x2 = 1.1
x1 = 5.0, x2 = 1.0
x1 = 4.9, x2 = .9
x1 = 4.8, x2 = .8
x1 = 4.7, x2 = .7
x1 = 4.6, x2 = .6186184274
x1 = 4.5, x2 = .6290333305
x1 = 4.4, x2 = .6357972981
x1 = 4.3, x2 = .6414383048
x1 = 4.2, x2 = .6458302999
x1 = 4.1, x2 = .6488088438
x1 = 4.071616076, x2 = .6501923454
x1 = 4.071504896, x2 = .6502675557
proc (x, delx, xmin, xmax) local temp; temp := x-delx; if temp < xmin then 
RETURN(1/2*x-1/2*xmin) elif xmax < temp then RETURN(1/2*x-1/2*xmax) else RETURN
(delx) fi end
x1 = 5.8, x2 = 5.8
x1 = 5.900000000, x2 = 2.900000000
x1 = 5.873436735, x2 = 1.450000000
x1 = 4.523764121, x2 = .158508392
x1 = 4.127167819, x2 = .4696891092
x1 = 4.077761466, x2 = .6333021784
x1 = 4.071566589, x2 = .6501284605
result := [x1 = 4.071504897, x2 = .6502675527]
WARNING: tolerance may be too small
z = 5.0
z = 3.571428571
z = 3.078817734
z = 3.001967369
z = 3.000001288
z = 3.000000000

Warning, new definition for norm
Warning, new definition for trace
See ?share and ?share,contents for information about the share library
Share Library:  coxeter
Author: John Stembridge.
Description:  The coxeter package contains 30 basic procedures for studying roots systems and finite Coxeter groups.  It can be used with The weyl package which contains an additional seven procedures for manipulating weight vectors and computing multiplicities for irreducible representations of semisimple Lie algebras.
Warning, new definition for rank
Share Library:  weyl
Author: John Stembridge.
Description:  The weyl package is a supplement to the coxeter package that contains 7 procedures for manipulating weight vectors and computing multiplicities for irreducible representations of semisimple Lie algebras.
Share Library:  dynkin
Author: Joyner, David.
Description:  The dynkin share package contains routines  to 1. draw the Dynkin diagram and extended Dynkin diagram of a simple Lie algebra, 2. plot weight systems (in various ways) for rank  2 and 3 simple Lie algebras, 3. creates the basis matrices and structure constants for the classical Lie algebras.
ok
ok
ok
ok

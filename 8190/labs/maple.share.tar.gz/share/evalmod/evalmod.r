See ?share and ?share,contents for information about the share library
Share Library:  evalmod
Author: Michael Monagan.
Description:  evalmod(a,b,x) evaluates a rational expression a(x) mod b(x) powmod(a,n,b,x) computes the polynomial a(x)^n mod b(x) Where b(x) is a polynomial in x over Q, Zp, Q(Y) of Zp(Y)
okay
okay
okay
okay
okay
okay

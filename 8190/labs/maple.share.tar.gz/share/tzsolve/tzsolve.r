See ?share and ?share,contents for information about the share library
Share Library:  tzsolve
Author: Almeida, Antonio.
Description:  a PDE solver for hyperbolic and parabolic 1D problems
`Ok - test #1 !`
`Ok - test #2 !`

See ?share and ?share,contents for information about the share library
Share Library:  Collatz
Author: Gonnet, Gaston.
Description:  Performs number of iterations in Collatz's problem,
i.e., the 3x+1 conjecture
Error, DistTo1 expects its 1st argument, n, to be of type posint, but received 
-1
Error, DistTo1 expects its 1st argument, n, to be of type posint, but received 
n
okay
okay
okay
okay
okay

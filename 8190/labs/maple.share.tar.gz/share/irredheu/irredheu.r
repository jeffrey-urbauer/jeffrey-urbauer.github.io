See ?share and ?share,contents for information about the share library
Share Library:  irredheu
Authors: Monagan, Michael B., Kaltofen, Erich.
Description:  A heuristic irreducibility test of polynomials in Q[x] via finding prime evaluations and integer primality testing (conjectured to be a polynomial time test)
okay
okay
okay
okay
okay
okay
okay
okay
okay

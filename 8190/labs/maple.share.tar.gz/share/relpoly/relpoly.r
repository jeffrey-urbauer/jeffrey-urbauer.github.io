See ?share and ?share,contents for information about the share library
Share Library:  relpoly
Author: Monagan, Michael.
Description:  The function relpoly(G,p) computes the all terminal reliability polynomial for a graph G with probability of edge failure p.
okay
okay

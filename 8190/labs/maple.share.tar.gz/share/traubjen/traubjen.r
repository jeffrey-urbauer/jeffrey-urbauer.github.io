See ?share and ?share,contents for information about the share library
Share Library:  traubjen
Author: Salvy, Bruno.
Description:  Traub-Jenkins algorithm for computing the complex roots of a polynomial in R[x] or C[x]
okay
okay
okay
okay
okay
okay

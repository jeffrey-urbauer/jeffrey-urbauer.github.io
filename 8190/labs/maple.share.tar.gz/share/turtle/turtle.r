See ?share and ?share,contents for information about the share library
Share Library:  turtle
Authors: Lozano, Eugenio Roanes, Macias, Eugenio Roanes.
Description:  package for supporting the Turtle graphics

                                                                               
                                                                               
                                       H                                       
                                       H                                       
                                       H                                       
                                       H                                       
                                       H                                       
                                       H                                       
                                       H                                       
                                       H                                       
                                       H                                       
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               

           HHHHHHHHHHHHHHHHHHHHHHHHHHHHH                                       
           H                           H                                       
           H                           H                                       
           H                           H                                       
           H                           H                                       
           H                           H                                       
           H                           H                                       
           H                           H                                       
           H                           H                                       
           H                           H                                       
           HHHHHHHHHHHHHHHHHHHHHHHHHHHHH                                       
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               

                                                                               
                                                                               
                                                                               
                                                                      HHHHHHHH 
                                                              HHHHHHHHH        
                                                              H                
                                                       HHHHHHHH                
                                               HHHHHHHHH                       
                                               H                               
                                       HHHHHHHHH                               
                                       H                                       
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               

                                                                               
                                                                               
                                                                               
                                                                      HHHHHHHH 
                                                              HHHHHHHHH        
                                                                               
                                                       HHHHHHHH                
                                               HHHHHHHHH                       
                                                                               
                                       HHHHHHHHH                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               

                            HHHHHHHHHHHHHHHHHHHHHHHH                           
                        HHHHHHHHHHHH        HHHHHHHHHHHH                       
                   HHHHHHH     H    HHHHHHHHH   H     HHHHHHH                  
                 HH   HHHHHHHHH        HHH       HHHHHHHHH   HH                
                HHHHHHH      HHHHHH  HH   HH HHHHHH      HHHHHHH               
              HHH     H      H     HHH     HH     H      H     HHH             
             HHH     HHHHHHHHHH     H H  HHH     HHHHHHHHHH     HHH            
           HH  HHHHHH  HH     HHHHHHH  HH  HHHHHHH     HH  HHHHHH  HH          
           H  HHH        H     HH   HH H   H   HH     H        HHH  H          
           H HH  H    HHHHHHHHHHHHHHHHHH HHHHHHHHHHHHHHHHH    H  HH H          
           HH     HHHH        HHHHHHHHHHHHHHHHHHHH        HHHH     HH          
           H HH  H    HHHHHHHHHHHHHHHHHH HHHHHHHHHHHHHHHHH    H  HH H          
           H  HHH        H     HH   HH H   H   HH     H        HHH  H          
           HH  HHHHHH  HH     HHHHHHH  HH  HHHHHHH     HH  HHHHHH  HH          
             HHH     HHHHHHHHHH     H H  HHH     HHHHHHHHHH     HHH            
              HHH     H      H     HHH     HH     H      H     HHH             
                HHHHHHH      HHHHHH  HH   HH HHHHHH      HHHHHHH               
                 HH   HHHHHHHHH        HHH       HHHHHHHHH   HH                
                   HHHHHHH     H    HHHHHHHHH   H     HHHHHHH                  
                        HHHHHHHHHHHH        HHHHHHHHHHHH                       
                            HHHHHHHHHHHHHHHHHHHHHHHH                           
                                                                               

                                                              HHHHHHH          
                                                        HHHHHH                 
                                                   HHHHH                       
                                               HHHH                            
                                               H                               
                                               H                               
                                               H                               
                                               H                               
                                               H                               
                                               H                               
                                       HHHHHHHHH                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               

                                                                               
                                                                               
                                                                               
                                                                               
                                                       HHH                     
                                                    HHH                        
                                                 HHH                           
                                               HHH                             
                                            HHH                                
                                         HHH                                   
                                       HH                                      
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               

                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                       H                                       
                                    HHH                                        
                                 HHH                                           
                               HH                                              
                            HHH                                                
                         HHH                                                   
                      HHH                                                      
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
okay
okay
okay

                                                                               
                                                                               
                                                                               
                                                                               
                              H                                                
                               HH                                              
                                 HH                                            
                                   H                                           
                                    HH                                         
                                      HH                                       
                                       H                                       
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               

                                                                               
                                                                               
                                                                               
                                 E  A  A   A  A                                
                              E   E  A A  A  A   A                             
                           EEE EE  E A A  A A  AA CCC                          
                         EEEE EE EEE A A  A AAA CC CCCC                        
                       EEEEE EEEEE EE AA A AAACCCCCCCCCCC                      
                      EEEEEEEEEEEEEEEEEAAAA*CCCCCCCCCCCCCC                     
                     EEEEEEEEEEEEEEEEEE*A*CCCCCCCCCCCCCCCCC                    
                     DDDDDDDDDDDD**********CCCCCCCCCCCCCCCC                    
                     DDDDDDDDDDDDDDDD**F*BBBBBBB***CCCCCCCC                    
                      DDDDDDDDDDDD*FFFFFFF*BBBBBBBBBBBBBBB                     
                       DDDDD DDDFF FF FF F FBBBBBBBBBBBBB                      
                         DDDD FF FFF F F  F FBB BB BBBB                        
                           FFF FF  F F F  F F  BB BBB                          
                              F   F  F F  F  F   B                             
                                 F  F  F   F  F                                
                                                                               
                                                                               
                                                                               
                                                                               

                                       H                                       
                                       H                                       
                                       H                                       
                                       H                                       
                                       H                                       
                                       H                                       
                                       H                                       
                                       H                                       
                                       H                                       
                                       H                                       
                                       H                                       
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               
                                                                               

                                                                               
                                                                               
                                                                               
                 HHH     HHHH                      HHHH     HHH                
              HHHHH        HHHHH                HHHHH        HHHHH             
              H    HHH  HHH   HH                HH   HHH  HHH    H             
                     HHHH                              HHHH                    
     H H              H                                  H              H H    
     HH               H                                  H               HH    
  HHHHHH              H                                  H              HHHHHH 
       HHH            H                                  H            HHH      
        HHHHHHHHHHHHHHHHH                              HHHHHHHHHHHHHHHHH       
  HHHHHH                 HHH                        HHH                 HHHHHH 
     HH                     HHH                  HHH                     HH    
     H H                       HHH             HHH                      H H    
                                  HH        HHH                                
                                    HHH  HHH                                   
                                       HH                                      
                                                                               
                                                                               
                                                                               
                                                                               

                                                                               
                                                                               
                                        H                                      
                                   HHHHHHHHHHH                                 
                               HHHHHHHHHHHHHHHHHHH                             
                          HHHHHHHHHHHHHHHHHHHHHHHHHHHHH                        
                    H HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH                   
                    H H H HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH H                   
                    H H H H H HHHHHHHHHHHHHHHHHHHHHH H H H H                   
                    H H H H H H H HHHHHHHHHHHHHH H H H H H H                   
                    H H H H H H H H H HHHH H H H H H H H H H                   
                    H H H H H H H H HHHHHHHH H H H H H H H H                   
                    H H H H H HHHHHHHHHHHHHHHHHHHH H H H H H                   
                    H H H HHHHHHHHHHHHHHHHHHHHHHHHHHHH H H H                   
                    H HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH H                   
                     HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH                    
                          HHHHHHHHHHHHHHHHHHHHHHHHHHHH                         
                               HHHHHHHHHHHHHHHHHHH                             
                                    HHHHHHHHH                                  
                                                                               
                                                                               
                                                                               

  HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH 
  HH HHH   H    HH H HH HH    H    HH HH H HH    H    HH HH H HH    H   HHH HH 
  H     HH H  HH     H    HHH H HHH    H     HHH H HHH    H     HH  H HH     H 
  HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH 
  H     HHHH HHH     H    HHHHHHHHH    H     HHHHHHHHH    H     HHH HHHH     H 
  HH HHH   H    HH H HH HH    H    HH HH H HH    H    HH HH H HH    H   HHH HH 
  HHHHH    H     HHH HHHHH    H     HHHH HHH     H    HHHHH HHH     H    HHHHH 
  HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH 
  HH HHH   H    HH H HH HH    H    HH HH H HH    H    HH HH H HH    H   HHH HH 
  H     HH H  HH     H    HHH H HHH    H     HHH H HHH    H     HH  H HH     H 
  HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH 
  H     HH H  HH     H    HHH H HHH    H     HHH H HHH    H     HH  H HH     H 
  HH HHH   H    HH H HH HH    H    HH HH H HH    H    HH HH H HH    H   HHH HH 
  HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH 
  HHHHH    H     HHH HHHHH    H     HHHH HHH     H    HHHHH HHH     H    HHHHH 
  HH HHH   H    HH H HH HH    H    HH HH H HH    H    HH HH H HH    H   HHH HH 
  H     HHHH HHH     H    HHHHHHHHH    H     HHHHHHHHH    H     HHH HHHH     H 
  HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH 
  H     HH H  HH     H    HHH H HHH    H     HHH H HHH    H     HH  H HH     H 
  HH HHH   H    HH H HH HH    H    HH HH H HH    H    HH HH H HH    H   HHH HH 
  HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH 
                                                                               

             HH                HHH                HHH                HHH       
             H H               H  H               H  H               H  H      
   HHH       H        HHH      H         HHH      H         HH       H         
   HHHHHHHH  H       HHHHHHHHH H        HHHHHHHHH H        HHHHHHHH  H         
          H  HHHHHHHH        H HHHHHHHHH        H HHHHHHHHH       H  HHHHHHHH  
       H  H       H       H  H      H        H  H      H        H H       H    
        HHH                HHH                HHH                HH            
             HH                HHH                HHH                HHH       
             H H               H  H               H  H               H  H      
   HHH       H        HHH      H         HHH      H         HH       H         
   HHHHHHHH  HHHHHHHHHHHHHHHHH HHHHHHHHHHHHHHHHHH HHHHHHHHHHHHHHHHH  HHHHHHHH  
          H       HH         H      HHH         H      HHH        H       HHH  
       H  H               H  H               H  H               H H            
        HHH                HHH                HHH                HH            
             HH                HHH                HHH                HHH       
     H       H H        H      H  H        H      H  H       H       H  H      
   HHHHHHHH  H       HHHHHHHHH H        HHHHHHHHH H        HHHHHHHH  H         
          H  HHHHHHHH        H HHHHHHHHH        H HHHHHHHHH       H  HHHHHHHH  
          H       HH         H      HHH         H      HHH        H       HHH  
       H  H               H  H               H  H               H H            
        HHH                HHH                HHH                HH            
                                                                               

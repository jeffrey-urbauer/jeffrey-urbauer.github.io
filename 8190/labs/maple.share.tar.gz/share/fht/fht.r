See ?share and ?share,contents for information about the share library
Share Library:  fht
Author: Earl, Stephen.
Description:  Package for the calculation of the Fast Hartley Transform
okay
okay
okay

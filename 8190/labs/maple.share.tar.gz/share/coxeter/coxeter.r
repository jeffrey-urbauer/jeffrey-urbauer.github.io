See ?share and ?share,contents for information about the share library
Share Library:  coxeter
Author: John Stembridge.
Description:  The coxeter package contains 30 basic procedures for studying roots systems and finite Coxeter groups.  It can be used with The weyl package which contains an additional seven procedures for manipulating weight vectors and computing multiplicities for irreducible representations of semisimple Lie algebras.
Share Library:  weyl
Author: John Stembridge.
Description:  The weyl package is a supplement to the coxeter package that contains 7 procedures for manipulating weight vectors and computing multiplicities for irreducible representations of semisimple Lie algebras.
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY
OKAY

           2
           |
   1---3---4---5---6---7---8

tin[23] := []

   1=<=2---3

   4=<=5---6

       8
       |
   7---9---10

tin[24] := []
1, " -- okay"
2, " -- okay"
3, " -- okay"
4, " -- okay"
6, " -- okay"
7, " -- okay"
8, " -- okay"
9, " -- okay"
10, " -- okay"
11, " -- okay"
12, " -- okay"
13, " -- okay"
14, " -- okay"
15, " -- okay"
16, " -- okay"
17, " -- okay"
18, " -- okay"
19, " -- okay"
20, " -- okay"
21, " -- okay"
22, " -- okay"
23, " -- okay"
24, " -- okay"
25, " -- okay"
26, " -- okay"
27, " -- okay"
28, " -- okay"
29, " -- okay"
30, " -- okay"
31, " -- okay"
32, " -- okay"
33, " -- okay"
34, " -- okay"
35, " -- okay"
36, " -- okay"
37, " -- okay"
38, " -- okay"
39, " -- okay"
40, " -- okay"
42, " -- okay"
43, " -- okay"
44, " -- okay"
45, " -- okay"
46, " -- okay"
47, " -- okay"
48, " -- okay"
49, " -- okay"
50, " -- okay"
51, " -- okay"
52, " -- okay"
53, " -- okay"
54, " -- okay"
55, " -- okay"
56, " -- okay"
57, " -- okay"
58, " -- okay"
59, " -- okay"
60, " -- okay"
61, " -- okay"
62, " -- okay"
63, " -- okay"
64, " -- okay"
65, " -- okay"
66, " -- okay"
67, " -- okay"
68, " -- okay"
69, " -- okay"
70, " -- okay"
71, " -- okay"
72, " -- okay"
73, " -- okay"
74, " -- okay"
75, " -- okay"
76, " -- okay"
77, " -- okay"
78, " -- okay"
79, " -- okay"
80, " -- okay"
81, " -- okay"
82, " -- okay"
83, " -- okay"
84, " -- okay"
85, " -- okay"
86, " -- okay"
87, " -- okay"
88, " -- okay"
89, " -- okay"
90, " -- okay"
91, " -- okay"

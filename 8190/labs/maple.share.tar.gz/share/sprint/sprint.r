See ?share and ?share,contents for information about the share library
Share Library:  sprint
Author: Michael Monagan.
Description:  Utility routine `short print` for displaying large expressions, allowing the user to look at the structure (top levels) of a large expression.
MATRIX([[Sum(x^i+1/(x^i),i = 1 .. n), 1, alpha], [-85*x^5-55*x^4-37*x^3-35*x^2+
97*x+50, 0, 1+x/`<<+2>>`], [u*v*w*x*y*z, Int(exp(-x)*x^2,x), -exp(-x)*x^2-2*x*
exp(-x)-2*exp(-x)]])
MATRIX([[`<<Sum[2]>>`, 1, alpha], [`<<+6>>`, 0, `<<+2>>`], [u*v*w*x*y*z, Int(
exp(-x)*x^2,x), `<<+3>>`]])
MATRIX([[Sum(x^i+1/(x^i),i = 1 .. n), 1, alpha], [-85*x^5-55*x^4-37*x^3-35*x^2+
97*x+50, 0, 1+x/(1+x/(-2+x/(-3+x/(2+`<<*2>>`))))], [u*v*w*x*y*z, Int(exp(-x)*x^
2,x), -exp(-x)*x^2-2*x*exp(-x)-2*exp(-x)]])

See ?share and ?share,contents for information about the share library
Share Library:  tex
Author: Yunliang Yu.
Description:  For generating LaTeX, plain TeX and AMS TeX output.
Includes facilities for breaking up large expressions
(for sums and products and vectors but not quotients)
test_(ams)

$ {e^{\left (f(y)\right )^{2}-y}} $

$ {e^{\left (f(y)\right )^{2}-y}} $

$ f_3\!\left((a-b)\,(b-c)\right) $

$ f_3\!\left((a-b)\,(b-c)\right) $

$ G\!\left(a^2-2\,b^3\right) $

$ G\!\left(-2\,b^3+a^2\right) $

$ f\!\left(\frac{f(y)^2}{3}-1\right) $

$ f\!\left(\frac{f(y)^2}{3}-1\right) $

$ G\!\left(f(y)^2-1\right)^3a\,H $

$ G\!\left(f(y)^2-1\right)^3H\,a $

$ y-\frac{y^3}{6}+\frac{y^5}{120}+O\!\left(y^6\right) $

$ \frac{y^5}{120}-\frac{y^3}{6}+y+O\!\left(y^6\right) $

$ d=2 $

$ d=2 $

$ a_{2\,3;4\,5} $

$ a_{2\,3;4\,5} $

$ a_{b_3\,c_{4;5}} $

$ a_{b_3\,c_{4;5}} $

$ 7\ldots 4 $

$ 7\ldots 4 $

$ 457658976.456874585476854 $

$ 457658976.456874585476854 $

$ 0.000000065843768546 $

$ 0.000000065843768546 $

$ \root{4}\of{a} $

$ \root{4}\of{a} $

$ \frac{4\,f(y)^5-77\,f(y)^4+40\,f(y)^3+21\,f(y)^2+55\,f(y)+61}{16\,f(
y)^2-44\,f(y)^3-70\,f(y)^4-23\,f(y)^4\,y-67\,f(y)^3\,y^2-97\,f(y)^2\,y
^3+10} $

$$ \align & {-}\left(4\,f(y)^5-77\,f(y)^4+40\,f(y)^3+21\,f(y)^2+55\,f(
y)+61\right)\Big/\left(23\,f(y)^4\,y\right. \\&\quad \left.{}+67\,f(y)
^3\,y^2+97\,y^3\,f(y)^2+70\,f(y)^4+44\,f(y)^3-16\,f(y)^2-10\right)
 \endalign $$

$$ \align & {-}278\,\sin(d)^2\,m+1818\,\sin(d)\,m\,\sqrt{a}-2448\,m-84
\,m^3\,a-84\,\sin(d)\,a^{3/2} \\&\quad -474\,m^2+507\,\sin(d)\,m^2-
388800+78\,\sin(d)^2\,m\,\sqrt{a}-492\,a^2+234\,m^4-22\,m^5 \\&\quad -
19224\,\sin(d)\,\sqrt{a}+2664\,\sin(d)^2\,\sqrt{a}+77\,\sin(d)^4\,m+
120\,\sin(d)^4-26\,\sin(d)^5 \\&\quad -72\,a^{3/2}-32\,\sin(d)\,m^3+
19236\,\sin(d)^2 \endalign $$

$$ \align & {-}492\,a^2-84\,m^3\,a-26\,\sin(d)^5+77\,\sin(d)^4\,m-22\,
m^5+120\,\sin(d)^4-32\,m^3\, \\&\quad \sin(d)+234\,m^4-278\,\sin(d)^2
\,m+78\,\sqrt{a}\,\sin(d)^2\,m+507\,m^2\,\sin(d) \\&\quad +2664\,
\sqrt{a}\,\sin(d)^2+19236\,\sin(d)^2+1818\,\sqrt{a}\,\sin(d)\,m-474\,m
^2-84\,a^{3/2}\,\sin(d) \\&\quad -19224\,\sqrt{a}\,\sin(d)-2448\,m-
388800-72\,a^{3/2} \endalign $$

$ \left(a\,(f-e)-b\,e\,f\right)f(y)\,y-f(y)\,y^2-f(y)^3-1 $

$ {-}f(y)^3-y^2\,f(y)-\left(b\,e\,f+a\,(e-f)\right)f(y)\,y-1 $

$ x_1\,x_2\,x_3-x_1\,x_2\,y_3-5\,x_1\,x_2\,z_3-x_1\,y_2-x_1-a\,x_1\,y_
1-a\,z_1\,z_3-1 $

$ {-}a\,x_1\,y_1+x_3\,x_2\,x_1-y_3\,x_2\,x_1-5\,z_3\,x_2\,x_1-y_2\,x_1
-x_1-a\,z_3\,z_1-1 $

$ a\,b\,c\,d\left(e-f^2\right)f(y)\,y\,z $

$ {-}a\,b\,c\,d\left(f^2-e\right)f(y)\,y\,z $

$ a\,b\,c\,d\,\left(e-f^2\right)^3f(y)\,y\,z $

$ {-}a\,b\,c\,d\,\left(f^2-e\right)^3f(y)\,y\,z $

$ [\,a,\,b,\,c,\,d\,] $

$ [\,a,\,b,\,c,\,d\,] $

$ \{\,34\,\} $

$ \{\,34\,\} $

$$ \align & [\,1,\,2,\,3,\,4,\,5,\,6,\,7,\,8,\,9,\,10,\,11,\,12,\,13
,\,14,\,15,\,16,\,17,\,18,\,19,\,20,\,21,\, \\&\quad 22,\,23,\,24,\,25
,\,26,\,27,\,28,\,29,\,30,\,31,\,32,\,33,\,34,\,35,\,36,\,37,\,38,\,39
,\, \\&\quad 40,\,41,\,42,\,43,\,44,\,45,\,46,\,47,\,48,\,49,\,50\,]
 \endalign $$

$$ \align & [\,1,\,2,\,3,\,4,\,5,\,6,\,7,\,8,\,9,\,10,\,11,\,12,\,13
,\,14,\,15,\,16,\,17,\,18,\,19,\,20,\,21,\, \\&\quad 22,\,23,\,24,\,25
,\,26,\,27,\,28,\,29,\,30,\,31,\,32,\,33,\,34,\,35,\,36,\,37,\,38,\,39
,\, \\&\quad 40,\,41,\,42,\,43,\,44,\,45,\,46,\,47,\,48,\,49,\,50\,]
 \endalign $$

$$ \align & \left[\,2\,f(y)\,y^2-f(y)-y-1,\,2\,f(y)\,y^2-f(y)-y-1,\,2
\,f(y)\,y^2-f(y)\right. \\&\quad -y-1,\,2\,f(y)\,y^2-f(y)-y-1,\,2\,f(y
)\,y^2-f(y)-y-1,\,2\,f(y)\,y^2 \\&\quad -f(y)-y-1,\,2\,f(y)\,y^2-f(y)-
y-1,\,2\,f(y)\,y^2-f(y)-y-1,\, \\&\quad \left.{}2\,f(y)\,y^2-f(y)-y-1
,\,2\,f(y)\,y^2-f(y)-y-1\,\right] \endalign $$

$$ \align & \left[\,2\,y^2\,f(y)-f(y)-y-1,\,2\,y^2\,f(y)-f(y)-y-1,\,2
\,y^2\,f(y)-f(y)\right. \\&\quad -y-1,\,2\,y^2\,f(y)-f(y)-y-1,\,2\,y^2
\,f(y)-f(y)-y-1,\,2\,y^2\,f(y) \\&\quad -f(y)-y-1,\,2\,y^2\,f(y)-f(y)-
y-1,\,2\,y^2\,f(y)-f(y)-y-1,\,2\,y^2\, \\&\quad \left.{}f(y)-f(y)-y-1
,\,2\,y^2\,f(y)-f(y)-y-1\,\right] \endalign $$

$ [\,\,] $

$ [\,\,] $

$ \{\,\,\} $

$ \{\,\,\} $

$ 2\,a^2\,{b_5}^3-2/3\,{v_1}^3+a\,b\,c $

$ 2\,{b_5}^3\,a^2+a\,b\,c-2/3\,{v_1}^3 $

$ \&\hat{}(w_1,\,w_2,\,w_3) $

$ \&\hat{}(w_1,\,w_2,\,w_3) $

$ a^{\beta}\,b $

$ a^{\beta}\,b $

$ {-}f(y)\left(y-f(y)\right) $

$ f(y)\left(f(y)-y\right) $

$ {-}3\,a^4\,b\,c_5\,(d-e)\,f\,(a-b)\,h $

$ {-}3\,a^4\,b\,f\,h\,c_5\,(a-b)\,(d-e) $

$ f\!\left(f(y)\right)a $

$ f\!\left(f(y)\right)a $

$ 4/3\,a\,b^3\,c\,d_5\,(e-f)\left(g-h^4\right)k\,(m-n)^r\,p $

$ {-}4/3\,k\,(m-n)^r\,p\,b^3\,a\,c\,d_5\left(h^4-g\right)(e-f) $

$ {-}5\,a^3\,b\left(4\,c-d\,(e-f)\right)-\sin\!\left(f(y)\right)^5-9\,
(m_{p\,q}-n_5)^6+15+(-1)^g $

$ 5\,a^3\,b\left(d\,(e-f)-4\,c\right)-\sin\!\left(f(y)\right)^5-9\,(m
_{p\,q}-n_5)^6+15+(-1)^g $

$$ \align & 8/27\,f(y)^3-4/21\,\frac{f(y)^2\,y}{z}+20/3\,f(y)^2\,z+2/
49\,\frac{f(y)\,y^2}{z^2}-20/7\,f(y)\,y \\&\quad +50\,f(y)\,z^2-\frac{
y^3}{343\,z^3}+\frac{15}{49}\,\frac{y^2}{z}-75/7\,y\,z+125\,z^3
 \endalign $$

$$ \align & 8/27\,f(y)^3+20/3\,f(y)^2\,z+50\,z^2\,f(y)+125\,z^3-4/21\,
\frac{f(y)^2\,y}{z}-20/7\,f(y)\,y \\&\quad -75/7\,y\,z+2/49\,\frac{y^2
\,f(y)}{z^2}+\frac{15}{49}\,\frac{y^2}{z}-\frac{y^3}{343\,z^3}
 \endalign $$

$ 3/5\,f(y)^3\,y\,(a-b)\,(b-d)^4\,z $

$ 3/5\,(b-d)^4\,(a-b)\,f(y)^3\,y\,z $

$ \left(a\,(f-e)-b\,e\,f\right)f(y)\,y-f(y)\,y^2-f(y)^3-1 $

$ {-}f(y)^3-y^2\,f(y)-\left(b\,e\,f+a\,(e-f)\right)f(y)\,y-1 $

$ \left(a\,(f-e)-b\,e\,f\right)f(y)\,y-f(y)\,y^2-f(y)^3-1 $

$ {-}f(y)^3-y^2\,f(y)-\left(b\,e\,f+a\,(e-f)\right)f(y)\,y-1 $

$ \left(x_2\,(x_3-y_3-5\,z_3)-y_2-1\right)x_1-a\,x_1\,y_1-a\,z_1\,z_3-
1 $

$ {-}a\,x_1\,y_1+\left((x_3-y_3-5\,z_3)\,x_2-y_2-1\right)x_1-a\,z_3\,z
_1-1 $

$ \left(\left(x_2\,(x_3-y_3-5\,z_3)-y_2-1\right)x_1-a\,x_1\,y_1-a\,z_1
\,z_3-1\right)^2 $

$ \left(a\,x_1\,y_1-\left((x_3-y_3-5\,z_3)\,x_2-y_2-1\right)x_1+a\,z_3
\,z_1+1\right)^2 $

$ (b-a-c)^3 $

$ {-}(a-b+c)^3 $

$ 2\,a\,b\,\left(b-\frac{a}{c}\right)^3f(y)\,y-1 $

$ 2\,a\,b\,\left(b-\frac{a}{c}\right)^3f(y)\,y-1 $

$ f(y)-(b-a)\,y-a\,z-1 $

$ f(y)+(a-b)\,y-a\,z-1 $

$ \frac{1}{20\,b} $

$ \frac{1}{20\,b} $

$$ \align & d(f)\leq -f(y)^{10}-10\,f(y)^9\,y-45\,f(y)^8\,y^2-120\,f(y
)^7\,y^3-210\,f(y)^6\,y^4 \\&\quad -252\,f(y)^5\,y^5-210\,f(y)^4\,y^6-
120\,f(y)^3\,y^7-45\,f(y)^2\,y^8-10\,f(y)\,y^9-y^{10} \endalign $$

$$ \align & d(f)\leq -f(y)^{10}-10\,f(y)^9\,y-45\,f(y)^8\,y^2-120\,f(y
)^7\,y^3-210\,f(y)^6\,y^4 \\&\quad -252\,f(y)^5\,y^5-210\,y^6\,f(y)^4-
120\,y^7\,f(y)^3-45\,y^8\,f(y)^2-10\,y^9\,f(y)-y^{10} \endalign $$

$ a\,\pmatrix f \endpmatrix  $

$ \pmatrix f \endpmatrix \,a $

$ v=\pmatrix f \endpmatrix ^2 $

$ v=\pmatrix f \endpmatrix ^2 $

$$ \pmatrix g & t \endpmatrix  $$

$$ \pmatrix g & t \endpmatrix  $$
exit
test_(la)

$ {e^{\left (f(y)\right )^{2}-y}} $

$ {e^{\left (f(y)\right )^{2}-y}} $

$ f_3\!\left((a-b)\,(b-c)\right) $

$ f_3\!\left((a-b)\,(b-c)\right) $

$ G\!\left(a^2-2\,b^3\right) $

$ G\!\left(-2\,b^3+a^2\right) $

$ f\!\left(\frac{f(y)^2}{3}-1\right) $

$ f\!\left(\frac{f(y)^2}{3}-1\right) $

$ G\!\left(f(y)^2-1\right)^3a\,H $

$ G\!\left(f(y)^2-1\right)^3H\,a $

$ y-\frac{y^3}{6}+\frac{y^5}{120}+O\!\left(y^6\right) $

$ \frac{y^5}{120}-\frac{y^3}{6}+y+O\!\left(y^6\right) $

$ d=2 $

$ d=2 $

$ a_{2\,3;4\,5} $

$ a_{2\,3;4\,5} $

$ a_{b_3\,c_{4;5}} $

$ a_{b_3\,c_{4;5}} $

$ 7\ldots 4 $

$ 7\ldots 4 $

$ 457658976.456874585476854 $

$ 457658976.456874585476854 $

$ 0.000000065843768546 $

$ 0.000000065843768546 $

$ \sqrt[4]{a} $

$ \sqrt[4]{a} $

$ \frac{4\,f(y)^5-77\,f(y)^4+40\,f(y)^3+21\,f(y)^2+55\,f(y)+61}{16\,f(
y)^2-44\,f(y)^3-70\,f(y)^4-23\,f(y)^4\,y-67\,f(y)^3\,y^2-97\,f(y)^2\,y
^3+10} $

\begin{eqnarray*} && -\left(4\,f(y)^5-77\,f(y)^4+40\,f(y)^3+21\,f(y)^2
+55\,f(y)+61\right)\Big/\left(23\,f(y)^4\,y\right. \\&&\quad{}\left.{}
+67\,f(y)^3\,y^2+97\,y^3\,f(y)^2+70\,f(y)^4+44\,f(y)^3-16\,f(y)^2-10
\right) \end{eqnarray*}

\begin{eqnarray*} && -278\,\sin(d)^2\,m+1818\,\sin(d)\,m\,\sqrt{a}-
2448\,m-84\,m^3\,a-84\,\sin(d)\,a^{3/2} \\&&\quad{}-474\,m^2+507\,\sin
(d)\,m^2-388800+78\,\sin(d)^2\,m\,\sqrt{a}-492\,a^2+234\,m^4-22\,m^5
 \\&&\quad{}-19224\,\sin(d)\,\sqrt{a}+2664\,\sin(d)^2\,\sqrt{a}+77\,
\sin(d)^4\,m+120\,\sin(d)^4-26\,\sin(d)^5 \\&&\quad{}-72\,a^{3/2}-32\,
\sin(d)\,m^3+19236\,\sin(d)^2 \end{eqnarray*}

\begin{eqnarray*} && -492\,a^2-84\,m^3\,a-26\,\sin(d)^5+77\,\sin(d)^4
\,m-22\,m^5+120\,\sin(d)^4-32\,m^3\, \\&&\quad{}\sin(d)+234\,m^4-278\,
\sin(d)^2\,m+78\,\sqrt{a}\,\sin(d)^2\,m+507\,m^2\,\sin(d) \\&&\quad{}+
2664\,\sqrt{a}\,\sin(d)^2+19236\,\sin(d)^2+1818\,\sqrt{a}\,\sin(d)\,m-
474\,m^2-84\,a^{3/2}\,\sin(d) \\&&\quad{}-19224\,\sqrt{a}\,\sin(d)-
2448\,m-388800-72\,a^{3/2} \end{eqnarray*}

$ \left(a\,(f-e)-b\,e\,f\right)f(y)\,y-f(y)\,y^2-f(y)^3-1 $

$ -f(y)^3-y^2\,f(y)-\left(b\,e\,f+a\,(e-f)\right)f(y)\,y-1 $

$ x_1\,x_2\,x_3-x_1\,x_2\,y_3-5\,x_1\,x_2\,z_3-x_1\,y_2-x_1-a\,x_1\,y_
1-a\,z_1\,z_3-1 $

$ -a\,x_1\,y_1+x_3\,x_2\,x_1-y_3\,x_2\,x_1-5\,z_3\,x_2\,x_1-y_2\,x_1-x
_1-a\,z_3\,z_1-1 $

$ a\,b\,c\,d\left(e-f^2\right)f(y)\,y\,z $

$ -a\,b\,c\,d\left(f^2-e\right)f(y)\,y\,z $

$ a\,b\,c\,d\,\left(e-f^2\right)^3f(y)\,y\,z $

$ -a\,b\,c\,d\,\left(f^2-e\right)^3f(y)\,y\,z $

$ [\,a,\,b,\,c,\,d\,] $

$ [\,a,\,b,\,c,\,d\,] $

$ \{\,34\,\} $

$ \{\,34\,\} $

\begin{eqnarray*} && [\,1,\,2,\,3,\,4,\,5,\,6,\,7,\,8,\,9,\,10,\,11,\,
12,\,13,\,14,\,15,\,16,\,17,\,18,\,19,\,20,\,21,\, \\&&\quad{}22,\,23
,\,24,\,25,\,26,\,27,\,28,\,29,\,30,\,31,\,32,\,33,\,34,\,35,\,36,\,37
,\,38,\,39,\, \\&&\quad{}40,\,41,\,42,\,43,\,44,\,45,\,46,\,47,\,48,\,
49,\,50\,] \end{eqnarray*}

\begin{eqnarray*} && [\,1,\,2,\,3,\,4,\,5,\,6,\,7,\,8,\,9,\,10,\,11,\,
12,\,13,\,14,\,15,\,16,\,17,\,18,\,19,\,20,\,21,\, \\&&\quad{}22,\,23
,\,24,\,25,\,26,\,27,\,28,\,29,\,30,\,31,\,32,\,33,\,34,\,35,\,36,\,37
,\,38,\,39,\, \\&&\quad{}40,\,41,\,42,\,43,\,44,\,45,\,46,\,47,\,48,\,
49,\,50\,] \end{eqnarray*}

\begin{eqnarray*} && \left[\,2\,f(y)\,y^2-f(y)-y-1,\,2\,f(y)\,y^2-f(y)
-y-1,\,2\,f(y)\,y^2-f(y)\right. \\&&\quad{}-y-1,\,2\,f(y)\,y^2-f(y)-y-
1,\,2\,f(y)\,y^2-f(y)-y-1,\,2\,f(y)\,y^2 \\&&\quad{}-f(y)-y-1,\,2\,f(y
)\,y^2-f(y)-y-1,\,2\,f(y)\,y^2-f(y)-y-1,\, \\&&\quad{}\left.{}2\,f(y)
\,y^2-f(y)-y-1,\,2\,f(y)\,y^2-f(y)-y-1\,\right] \end{eqnarray*}

\begin{eqnarray*} && \left[\,2\,y^2\,f(y)-f(y)-y-1,\,2\,y^2\,f(y)-f(y)
-y-1,\,2\,y^2\,f(y)-f(y)\right. \\&&\quad{}-y-1,\,2\,y^2\,f(y)-f(y)-y-
1,\,2\,y^2\,f(y)-f(y)-y-1,\,2\,y^2\,f(y) \\&&\quad{}-f(y)-y-1,\,2\,y^2
\,f(y)-f(y)-y-1,\,2\,y^2\,f(y)-f(y)-y-1,\,2\,y^2\, \\&&\quad{}\left.{}
f(y)-f(y)-y-1,\,2\,y^2\,f(y)-f(y)-y-1\,\right] \end{eqnarray*}

$ [\,\,] $

$ [\,\,] $

$ \{\,\,\} $

$ \{\,\,\} $

$ 2\,a^2\,{b_5}^3-2/3\,{v_1}^3+a\,b\,c $

$ 2\,{b_5}^3\,a^2+a\,b\,c-2/3\,{v_1}^3 $

$ \&\hat{}(w_1,\,w_2,\,w_3) $

$ \&\hat{}(w_1,\,w_2,\,w_3) $

$ a^{\beta}\,b $

$ a^{\beta}\,b $

$ -f(y)\left(y-f(y)\right) $

$ f(y)\left(f(y)-y\right) $

$ -3\,a^4\,b\,c_5\,(d-e)\,f\,(a-b)\,h $

$ -3\,a^4\,b\,f\,h\,c_5\,(a-b)\,(d-e) $

$ f\!\left(f(y)\right)a $

$ f\!\left(f(y)\right)a $

$ 4/3\,a\,b^3\,c\,d_5\,(e-f)\left(g-h^4\right)k\,(m-n)^r\,p $

$ -4/3\,k\,(m-n)^r\,p\,b^3\,a\,c\,d_5\left(h^4-g\right)(e-f) $

$ -5\,a^3\,b\left(4\,c-d\,(e-f)\right)-\sin\!\left(f(y)\right)^5-9\,(m
_{p\,q}-n_5)^6+15+(-1)^g $

$ 5\,a^3\,b\left(d\,(e-f)-4\,c\right)-\sin\!\left(f(y)\right)^5-9\,(m
_{p\,q}-n_5)^6+15+(-1)^g $

\begin{eqnarray*} && 8/27\,f(y)^3-4/21\,\frac{f(y)^2\,y}{z}+20/3\,f(y)
^2\,z+2/49\,\frac{f(y)\,y^2}{z^2}-20/7\,f(y)\,y \\&&\quad{}+50\,f(y)\,
z^2-\frac{y^3}{343\,z^3}+\frac{15}{49}\,\frac{y^2}{z}-75/7\,y\,z+125\,
z^3 \end{eqnarray*}

\begin{eqnarray*} && 8/27\,f(y)^3+20/3\,f(y)^2\,z+50\,z^2\,f(y)+125\,z
^3-4/21\,\frac{f(y)^2\,y}{z}-20/7\,f(y)\,y \\&&\quad{}-75/7\,y\,z+2/49
\,\frac{y^2\,f(y)}{z^2}+\frac{15}{49}\,\frac{y^2}{z}-\frac{y^3}{343\,z
^3} \end{eqnarray*}

$ 3/5\,f(y)^3\,y\,(a-b)\,(b-d)^4\,z $

$ 3/5\,(b-d)^4\,(a-b)\,f(y)^3\,y\,z $

$ \left(a\,(f-e)-b\,e\,f\right)f(y)\,y-f(y)\,y^2-f(y)^3-1 $

$ -f(y)^3-y^2\,f(y)-\left(b\,e\,f+a\,(e-f)\right)f(y)\,y-1 $

$ \left(a\,(f-e)-b\,e\,f\right)f(y)\,y-f(y)\,y^2-f(y)^3-1 $

$ -f(y)^3-y^2\,f(y)-\left(b\,e\,f+a\,(e-f)\right)f(y)\,y-1 $

$ \left(x_2\,(x_3-y_3-5\,z_3)-y_2-1\right)x_1-a\,x_1\,y_1-a\,z_1\,z_3-
1 $

$ -a\,x_1\,y_1+\left((x_3-y_3-5\,z_3)\,x_2-y_2-1\right)x_1-a\,z_3\,z_1
-1 $

$ \left(\left(x_2\,(x_3-y_3-5\,z_3)-y_2-1\right)x_1-a\,x_1\,y_1-a\,z_1
\,z_3-1\right)^2 $

$ \left(a\,x_1\,y_1-\left((x_3-y_3-5\,z_3)\,x_2-y_2-1\right)x_1+a\,z_3
\,z_1+1\right)^2 $

$ (b-a-c)^3 $

$ -(a-b+c)^3 $

$ 2\,a\,b\,\left(b-\frac{a}{c}\right)^3f(y)\,y-1 $

$ 2\,a\,b\,\left(b-\frac{a}{c}\right)^3f(y)\,y-1 $

$ f(y)-(b-a)\,y-a\,z-1 $

$ f(y)+(a-b)\,y-a\,z-1 $

$ \frac{1}{20\,b} $

$ \frac{1}{20\,b} $

\begin{eqnarray*} && d(f)\leq -f(y)^{10}-10\,f(y)^9\,y-45\,f(y)^8\,y^2
-120\,f(y)^7\,y^3-210\,f(y)^6\,y^4 \\&&\quad{}-252\,f(y)^5\,y^5-210\,f
(y)^4\,y^6-120\,f(y)^3\,y^7-45\,f(y)^2\,y^8-10\,f(y)\,y^9-y^{10}
 \end{eqnarray*}

\begin{eqnarray*} && d(f)\leq -f(y)^{10}-10\,f(y)^9\,y-45\,f(y)^8\,y^2
-120\,f(y)^7\,y^3-210\,f(y)^6\,y^4 \\&&\quad{}-252\,f(y)^5\,y^5-210\,y
^6\,f(y)^4-120\,y^7\,f(y)^3-45\,y^8\,f(y)^2-10\,y^9\,f(y)-y^{10}
 \end{eqnarray*}

$ a\,\left(\begin{array}{c} f \end{array} \right) $

$ \left(\begin{array}{c} f \end{array} \right)\,a $

$ v=\left(\begin{array}{c} f \end{array} \right)^2 $

$ v=\left(\begin{array}{c} f \end{array} \right)^2 $

$$ \left(\begin{array}{cc} g & t \end{array} \right) $$

$$ \left(\begin{array}{cc} g & t \end{array} \right) $$
exit
test_(pln)

$ {e^{\left (f(y)\right )^{2}-y}} $

$ {e^{\left (f(y)\right )^{2}-y}} $

$ f_3\!\left((a-b)\,(b-c)\right) $

$ f_3\!\left((a-b)\,(b-c)\right) $

$ G\!\left(a^2-2\,b^3\right) $

$ G\!\left(-2\,b^3+a^2\right) $

$ f\!\left({f(y)^2\over 3}-1\right) $

$ f\!\left({f(y)^2\over 3}-1\right) $

$ G\!\left(f(y)^2-1\right)^3a\,H $

$ G\!\left(f(y)^2-1\right)^3H\,a $

$ y-{y^3\over 6}+{y^5\over 120}+O\!\left(y^6\right) $

$ {y^5\over 120}-{y^3\over 6}+y+O\!\left(y^6\right) $

$ d=2 $

$ d=2 $

$ a_{2\,3;4\,5} $

$ a_{2\,3;4\,5} $

$ a_{b_3\,c_{4;5}} $

$ a_{b_3\,c_{4;5}} $

$ 7\ldots 4 $

$ 7\ldots 4 $

$ 457658976.456874585476854 $

$ 457658976.456874585476854 $

$ 0.000000065843768546 $

$ 0.000000065843768546 $

$ \root{4}\of{a} $

$ \root{4}\of{a} $

$ {4\,f(y)^5-77\,f(y)^4+40\,f(y)^3+21\,f(y)^2+55\,f(y)+61\over 16\,f(y
)^2-44\,f(y)^3-70\,f(y)^4-23\,f(y)^4\,y-67\,f(y)^3\,y^2-97\,f(y)^2\,y^
3+10} $

$$ \eqalign{& {-}\left(4\,f(y)^5-77\,f(y)^4+40\,f(y)^3+21\,f(y)^2+55\,
f(y)+61\right)\Big/\left(23\,f(y)^4\,y\right. \cr&\quad \left.{}+67\,f
(y)^3\,y^2+97\,y^3\,f(y)^2+70\,f(y)^4+44\,f(y)^3-16\,f(y)^2-10\right)
 \cr} $$

$$ \eqalign{& {-}278\,\sin(d)^2\,m+1818\,\sin(d)\,m\,\sqrt{a}-2448\,m-
84\,m^3\,a-84\,\sin(d)\,a^{3/2} \cr&\quad -474\,m^2+507\,\sin(d)\,m^2-
388800+78\,\sin(d)^2\,m\,\sqrt{a}-492\,a^2+234\,m^4-22\,m^5 \cr&\quad 
-19224\,\sin(d)\,\sqrt{a}+2664\,\sin(d)^2\,\sqrt{a}+77\,\sin(d)^4\,m+
120\,\sin(d)^4-26\,\sin(d)^5 \cr&\quad -72\,a^{3/2}-32\,\sin(d)\,m^3+
19236\,\sin(d)^2 \cr} $$

$$ \eqalign{& {-}492\,a^2-84\,m^3\,a-26\,\sin(d)^5+77\,\sin(d)^4\,m-22
\,m^5+120\,\sin(d)^4-32\,m^3\, \cr&\quad \sin(d)+234\,m^4-278\,\sin(d)
^2\,m+78\,\sqrt{a}\,\sin(d)^2\,m+507\,m^2\,\sin(d) \cr&\quad +2664\,
\sqrt{a}\,\sin(d)^2+19236\,\sin(d)^2+1818\,\sqrt{a}\,\sin(d)\,m-474\,m
^2-84\,a^{3/2}\,\sin(d) \cr&\quad -19224\,\sqrt{a}\,\sin(d)-2448\,m-
388800-72\,a^{3/2} \cr} $$

$ \left(a\,(f-e)-b\,e\,f\right)f(y)\,y-f(y)\,y^2-f(y)^3-1 $

$ {-}f(y)^3-y^2\,f(y)-\left(b\,e\,f+a\,(e-f)\right)f(y)\,y-1 $

$ x_1\,x_2\,x_3-x_1\,x_2\,y_3-5\,x_1\,x_2\,z_3-x_1\,y_2-x_1-a\,x_1\,y_
1-a\,z_1\,z_3-1 $

$ {-}a\,x_1\,y_1+x_3\,x_2\,x_1-y_3\,x_2\,x_1-5\,z_3\,x_2\,x_1-y_2\,x_1
-x_1-a\,z_3\,z_1-1 $

$ a\,b\,c\,d\left(e-f^2\right)f(y)\,y\,z $

$ {-}a\,b\,c\,d\left(f^2-e\right)f(y)\,y\,z $

$ a\,b\,c\,d\,\left(e-f^2\right)^3f(y)\,y\,z $

$ {-}a\,b\,c\,d\,\left(f^2-e\right)^3f(y)\,y\,z $

$ [\,a,\,b,\,c,\,d\,] $

$ [\,a,\,b,\,c,\,d\,] $

$ \{\,34\,\} $

$ \{\,34\,\} $

$$ \eqalign{& [\,1,\,2,\,3,\,4,\,5,\,6,\,7,\,8,\,9,\,10,\,11,\,12,\,13
,\,14,\,15,\,16,\,17,\,18,\,19,\,20,\,21,\, \cr&\quad 22,\,23,\,24,\,
25,\,26,\,27,\,28,\,29,\,30,\,31,\,32,\,33,\,34,\,35,\,36,\,37,\,38,\,
39,\, \cr&\quad 40,\,41,\,42,\,43,\,44,\,45,\,46,\,47,\,48,\,49,\,50
\,] \cr} $$

$$ \eqalign{& [\,1,\,2,\,3,\,4,\,5,\,6,\,7,\,8,\,9,\,10,\,11,\,12,\,13
,\,14,\,15,\,16,\,17,\,18,\,19,\,20,\,21,\, \cr&\quad 22,\,23,\,24,\,
25,\,26,\,27,\,28,\,29,\,30,\,31,\,32,\,33,\,34,\,35,\,36,\,37,\,38,\,
39,\, \cr&\quad 40,\,41,\,42,\,43,\,44,\,45,\,46,\,47,\,48,\,49,\,50
\,] \cr} $$

$$ \eqalign{& \left[\,2\,f(y)\,y^2-f(y)-y-1,\,2\,f(y)\,y^2-f(y)-y-1,\,
2\,f(y)\,y^2-f(y)\right. \cr&\quad -y-1,\,2\,f(y)\,y^2-f(y)-y-1,\,2\,f
(y)\,y^2-f(y)-y-1,\,2\,f(y)\,y^2 \cr&\quad -f(y)-y-1,\,2\,f(y)\,y^2-f(
y)-y-1,\,2\,f(y)\,y^2-f(y)-y-1,\, \cr&\quad \left.{}2\,f(y)\,y^2-f(y)-
y-1,\,2\,f(y)\,y^2-f(y)-y-1\,\right] \cr} $$

$$ \eqalign{& \left[\,2\,y^2\,f(y)-f(y)-y-1,\,2\,y^2\,f(y)-f(y)-y-1,\,
2\,y^2\,f(y)-f(y)\right. \cr&\quad -y-1,\,2\,y^2\,f(y)-f(y)-y-1,\,2\,y
^2\,f(y)-f(y)-y-1,\,2\,y^2\,f(y) \cr&\quad -f(y)-y-1,\,2\,y^2\,f(y)-f(
y)-y-1,\,2\,y^2\,f(y)-f(y)-y-1,\,2\,y^2\, \cr&\quad \left.{}f(y)-f(y)-
y-1,\,2\,y^2\,f(y)-f(y)-y-1\,\right] \cr} $$

$ [\,\,] $

$ [\,\,] $

$ \{\,\,\} $

$ \{\,\,\} $

$ 2\,a^2\,{b_5}^3-2/3\,{v_1}^3+a\,b\,c $

$ 2\,{b_5}^3\,a^2+a\,b\,c-2/3\,{v_1}^3 $

$ \&\hat{}(w_1,\,w_2,\,w_3) $

$ \&\hat{}(w_1,\,w_2,\,w_3) $

$ a^{\beta}\,b $

$ a^{\beta}\,b $

$ {-}f(y)\left(y-f(y)\right) $

$ f(y)\left(f(y)-y\right) $

$ {-}3\,a^4\,b\,c_5\,(d-e)\,f\,(a-b)\,h $

$ {-}3\,a^4\,b\,f\,h\,c_5\,(a-b)\,(d-e) $

$ f\!\left(f(y)\right)a $

$ f\!\left(f(y)\right)a $

$ 4/3\,a\,b^3\,c\,d_5\,(e-f)\left(g-h^4\right)k\,(m-n)^r\,p $

$ {-}4/3\,k\,(m-n)^r\,p\,b^3\,a\,c\,d_5\left(h^4-g\right)(e-f) $

$ {-}5\,a^3\,b\left(4\,c-d\,(e-f)\right)-\sin\!\left(f(y)\right)^5-9\,
(m_{p\,q}-n_5)^6+15+(-1)^g $

$ 5\,a^3\,b\left(d\,(e-f)-4\,c\right)-\sin\!\left(f(y)\right)^5-9\,(m
_{p\,q}-n_5)^6+15+(-1)^g $

$$ \eqalign{& 8/27\,f(y)^3-4/21\,{f(y)^2\,y\over z}+20/3\,f(y)^2\,z+2/
49\,{f(y)\,y^2\over z^2}-20/7\,f(y)\,y \cr&\quad +50\,f(y)\,z^2-{y^3
\over 343\,z^3}+{15\over 49}\,{y^2\over z}-75/7\,y\,z+125\,z^3 \cr} $$

$$ \eqalign{& 8/27\,f(y)^3+20/3\,f(y)^2\,z+50\,z^2\,f(y)+125\,z^3-4/21
\,{f(y)^2\,y\over z}-20/7\,f(y)\,y \cr&\quad -75/7\,y\,z+2/49\,{y^2\,f
(y)\over z^2}+{15\over 49}\,{y^2\over z}-{y^3\over 343\,z^3} \cr} $$

$ 3/5\,f(y)^3\,y\,(a-b)\,(b-d)^4\,z $

$ 3/5\,(b-d)^4\,(a-b)\,f(y)^3\,y\,z $

$ \left(a\,(f-e)-b\,e\,f\right)f(y)\,y-f(y)\,y^2-f(y)^3-1 $

$ {-}f(y)^3-y^2\,f(y)-\left(b\,e\,f+a\,(e-f)\right)f(y)\,y-1 $

$ \left(a\,(f-e)-b\,e\,f\right)f(y)\,y-f(y)\,y^2-f(y)^3-1 $

$ {-}f(y)^3-y^2\,f(y)-\left(b\,e\,f+a\,(e-f)\right)f(y)\,y-1 $

$ \left(x_2\,(x_3-y_3-5\,z_3)-y_2-1\right)x_1-a\,x_1\,y_1-a\,z_1\,z_3-
1 $

$ {-}a\,x_1\,y_1+\left((x_3-y_3-5\,z_3)\,x_2-y_2-1\right)x_1-a\,z_3\,z
_1-1 $

$ \left(\left(x_2\,(x_3-y_3-5\,z_3)-y_2-1\right)x_1-a\,x_1\,y_1-a\,z_1
\,z_3-1\right)^2 $

$ \left(a\,x_1\,y_1-\left((x_3-y_3-5\,z_3)\,x_2-y_2-1\right)x_1+a\,z_3
\,z_1+1\right)^2 $

$ (b-a-c)^3 $

$ {-}(a-b+c)^3 $

$ 2\,a\,b\,\left(b-{a\over c}\right)^3f(y)\,y-1 $

$ 2\,a\,b\,\left(b-{a\over c}\right)^3f(y)\,y-1 $

$ f(y)-(b-a)\,y-a\,z-1 $

$ f(y)+(a-b)\,y-a\,z-1 $

$ {1\over 20\,b} $

$ {1\over 20\,b} $

$$ \eqalign{& d(f)\leq -f(y)^{10}-10\,f(y)^9\,y-45\,f(y)^8\,y^2-120\,f
(y)^7\,y^3-210\,f(y)^6\,y^4 \cr&\quad -252\,f(y)^5\,y^5-210\,f(y)^4\,y
^6-120\,f(y)^3\,y^7-45\,f(y)^2\,y^8-10\,f(y)\,y^9-y^{10} \cr} $$

$$ \eqalign{& d(f)\leq -f(y)^{10}-10\,f(y)^9\,y-45\,f(y)^8\,y^2-120\,f
(y)^7\,y^3-210\,f(y)^6\,y^4 \cr&\quad -252\,f(y)^5\,y^5-210\,y^6\,f(y)
^4-120\,y^7\,f(y)^3-45\,y^8\,f(y)^2-10\,y^9\,f(y)-y^{10} \cr} $$

$ a\,\pmatrix{ f \cr}  $

$ \pmatrix{ f \cr} \,a $

$ v=\pmatrix{ f \cr} ^2 $

$ v=\pmatrix{ f \cr} ^2 $

$$ \pmatrix{ g & t \cr}  $$

$$ \pmatrix{ g & t \cr}  $$

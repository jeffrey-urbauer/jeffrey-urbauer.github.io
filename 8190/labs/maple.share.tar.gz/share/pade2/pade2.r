See ?share and ?share,contents for information about the share library
Share Library:  pade2
Author: Harm Derksen.
Description:  computes a generalized Pade approximation
okay

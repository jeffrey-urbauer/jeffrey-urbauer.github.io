See ?share and ?share,contents for information about the share library
Share Library:  symmpoly
Author: Monagan, Michael.
Description:  Utility routine for generating the symmetric polynomials.
okay
okay

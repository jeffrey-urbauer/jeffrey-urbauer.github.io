See ?share and ?share,contents for information about the share library
Share Library:  kinetics
Author: Mark Holmes.
Description:  procedures that analyzes a reaction scheme, determining the system of differential equations, the associated conservation laws and some of the species that have a zero steady state

The differential equations are:

diff(a(t),t) = -k2*a-k4*a+k5*a+2*k6*b-k7*a*b-2*k9*a^2-k10*a^2-k11*a*b+k13*a*b-2
*k14*a^2-k15*a^2+2*k17*b*c
diff(b(t),t) = k2*a+k3*a+k4*a-k6*b-k7*a*b-k8*a*b+k9*a^2-k11*a*b-k12*a*b-k13*a*b
-k17*b*c
diff(c(t),t) = k4*a+k7*a*b+k11*a*b+k12*a*b+k14*a^2+k15*a^2-k17*b*c
diff(d(t),t) = k11*a*b+k14*a^2

`OK FOR TEST 1.a`


    There are no conservation laws.

`OK FOR TEST 1.b`

    No species were found to have a zero steady state.

`OK FOR TEST 1.c`

R := [2*OO < O2+Hv, O3+M < OO+O2+M, O2+OO < O3+Hv, 2*O2 < O3+OO]

The differential equations are:

diff(OO(t),t) = 2*k1*O2*Hv-k2*OO*O2*M+k3*Hv*O3-k4*OO*O3
diff(O2(t),t) = -k1*O2*Hv-k2*OO*O2*M+k3*Hv*O3+2*k4*OO*O3
diff(Hv(t),t) = -k1*O2*Hv-k3*Hv*O3
diff(O3(t),t) = k2*OO*O2*M-k3*Hv*O3-k4*OO*O3
diff(M(t),t) = 0


    The conservation laws are:

      1.    constant =   OO+2*O2+3*O3
      2.    constant =   M

`OK FOR TEST 2.a`

    No species were found to have a zero steady state.

`OK FOR TEST 2.b`

R := [y2 < u2, u2 < x, v2 < x, z2 < v2, v < x, x < v, z < v, u < x, x < u, y <
u]

The differential equations are:

diff(y2(t),t) = k1*u2
diff(u2(t),t) = -k1*u2+k2*x
diff(x(t),t) = -k2*x-k3*x-k5*x+k6*v-k8*x+k9*u
diff(v2(t),t) = k3*x-k4*v2
diff(z2(t),t) = k4*v2
diff(v(t),t) = k5*x-k6*v-k7*v
diff(z(t),t) = k7*v
diff(u(t),t) = k8*x-k9*u-k10*u
diff(y(t),t) = k10*u


    The conservation laws are:

      1.    constant =   y2*k7*k5+u2*k7*k5-k2*v*k7-k2*z*k6-k2*z*k7
      2.    constant =   -k10*x*k7*k5-k10*v*k7*k2-k10*v*k7*k3-k10*v*k7*k5-k10*v
*k7*k8-k10*z*k2*k7-k10*z*k7*k3-k10*z*k7*k5-k10*z*k7*k8-k10*z*k6*k8-k10*z*k6*k3-
k10*z*k6*k2+y*k7*k5*k9
      3.    constant =   x*k7*k5*k9+k10*x*k7*k5+k2*v*k7*k9+k10*v*k7*k2+k7*v*k5*
k9+k7*v*k3*k9+k10*v*k7*k3+k10*v*k7*k8+k10*v*k7*k5+z*k7*k2*k9+k10*z*k2*k7+z*k7*
k5*k9+z*k7*k9*k3+k10*z*k7*k3+k10*z*k7*k8+k10*z*k7*k5+z*k6*k2*k9+k10*z*k6*k2+z*
k6*k9*k3+k10*z*k6*k3+k10*z*k6*k8+u*k7*k5*k9
      4.    constant =   v2*k7*k5+z2*k7*k5-k7*v*k3-k3*z*k6-k3*z*k7

`OK FOR TEST 3.a`

    There are   5   species found to have a zero steady state
    They are:
              u2
              x
              v2
              v
              u

`OK FOR TEST 3.b`

See ?share and ?share,contents for information about the share library
Share Library:  macroC
Author: Patrick Capolsini.
Description:  C code generator for Maple
# include <math.h>
# include <stdio.h>
# include <simul.h>
# include  "toto.h" 

# define PI 0.3141593E1
# define SQUARE(num) num*num
# undef TOTO

# ifdef TOTO
# define ROWS 100
# define LINES 100
# else 
# define ROWS 10
# undef TOTO
# endif 

# ifndef TOTO
# define ROWS 1
# endif 

# if defined(TOTO) 
# define WELCOME toto
# elif defined(TITI) 
# define WELCOME titi
# elif defined(TUTU) 
# define WELCOME tutu
# else 
# define WELCOME tata
# endif 

# line 56 "toto.c" 
# error "This an ERROR message" 
# pragma inline

    /*                                                                  */
    /*      Inversion de matrice symmetrique definie positive           */
    /*                                                                  */

    /* Decomposition de cholesky */

    void cholesky(M,res,n)
    double **M,**res;
    int n;
      {
      int i,j,k;
      double tmp;
      for(j = 0;(j <= n-1);j++)
        {
        
        tmp = 0;
        for(k = 0;(k <= j-1);k++)
          tmp += pow(res[j][k],2.0);
        res[j][j] = sqrt(M[j][j]-tmp);
        for(i = j+1;(i <= n-1);i++)
          {
          
          tmp = 0;
          for(k = 0;(k <= j-1);k++)
            tmp += res[j][k]*res[i][k];
          res[i][j] = (M[j][i]-tmp)/res[j][j];
          res[j][i] = res[i][j];
          }
        }
      }

    /* Resoluton du systeme lineaire (MMt) X = b  */
    void resolution(M,X,b,n)
    double **M,*X,*b;
    int n;
      {
      int i,j;
      double tmp,*w,*dvector();
      void free_dvector();
      w = dvector(0,n-1);
      /* resolution de Mw = b */
      w[0] = b[0]/M[0][0];
      for(i = 1;(i <= n-1);i++)
        {
        
        tmp = 0;
        for(j = 0;(j <= i-1);j++)
          tmp += M[i][j]*w[j];
        w[i] = 1/M[i][i]*(b[i]-tmp);
        }
      /* resolution de (Mt) X = w */
      X[n-1] = w[n-1]/M[n-1][n-1];
      for(i = n-2;(0 <= i);i--)
        {
        
        tmp = 0;
        j = i+1;
        do
          {
          
          tmp += M[j][i]*X[j];
          j++;
          }
        while((j <= n-1))
        X[i] = 1/M[i][i]*(w[i]-tmp);
        }
      free_dvector(w,0,n-1);
      }

    /* Inversion de la matrice M apres decomposition */
    void inversion(M,res,n)
    double **M,**res;
    int n;
      {
      double **chol,*X,*base_vect,*dvector(),**dmatrix();
      int i,j;
      void free_dvector(),free_dmatrix();
      chol = dmatrix(0,n-1,0,n-1);
      X = dvector(0,n-1);
      base_vect = dvector(0,n-1);
      cholesky(M,chol,n);
      for(j = 0;(j <= n-1);j++)
        {
        
        for(i = 0;(i <= n-1);i++)
          base_vect[i] = 0;
        base_vect[j] = 1;
        resolution(chol,X,base_vect,n);
        i = 0;
        while((i <= n-1))
          {
          
          res[i][j] = X[i];
          i++;
          }
        }
      free_dmatrix(chol,0,n-1,0,n-1);
      free_dvector(X,0,n-1);
      free_dvector(base_vect,0,n-1);
      }

    typedef int integer;

    typedef     struct personnel_record
      {
        char firt_name[20];
        char last_name[25];
        int age;
        char hobby[20];
        float income;
      } PERSON;

    typedef     union numbers
      {
        char letter;
        int number;
        float dec_number;
        double precise_number;
      } NUMBER;

    enum digits {0,1,2,3,4,5,6,7,8,9} dig1,dig2,dig3;

    toto:
      {
      
      return (sqrt(2)/2-sqrt(-1)*sqrt(2)/2);
      break;
      continue;
      }

    goto toto;

    pointer = fopen( "file" , "rw" );
    if((scanf( "%c" , "&c" ) != EOF))
      printf ( "not end of file" );
    else 
      {
      
      printf ( "end of file" );
      return (EOF);
      }

    switch (letter)
      {
      
      case a :
        printf ( "a" );
      case A :
        printf ( "A" );
        printf ( "Uppercase" );
      default :
        printf ( "Other letter" );
      }
    fclose(pointer);

    void matrices()
      {
      
      toto[0][1] = x+pow(a,4.0);
      toto[1][1] = x*x+a*x;
      toto[1][0] = a*a;
      toto[0][0] = x*x*x;

      toto[0][0] = pow(x,4.0);
      toto[0][1] = 0;
      toto[0][2] = 0;
      toto[1][0] = x;
      toto[1][1] = x*x;
      toto[1][2] = 0;
      toto[2][0] = 0;
      toto[2][1] = 0;
      toto[2][2] = 0;

      toto[0][0] = 1;
      toto[0][1] = 0;
      toto[0][2] = 0;
      toto[1][0] = 0;
      toto[1][1] = 1;
      toto[1][2] = 0;
      toto[2][0] = 0;
      toto[2][1] = 0;
      toto[2][2] = 1;
      matrices();
      }
!

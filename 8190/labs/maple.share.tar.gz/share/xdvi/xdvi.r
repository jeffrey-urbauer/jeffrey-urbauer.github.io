See ?share and ?share,contents for information about the share library
Share Library:  xdvi
Author: Michael Monagan.
Description:  This allows the user to easily preview Maple output in LaTeX
ok

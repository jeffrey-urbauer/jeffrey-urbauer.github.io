See ?share and ?share,contents for information about the share library
Share Library:  trans
Author: Grotendorst, Johannes.
Description:  routines for rational function approximations to rational points, Taylor and asymptotic series and functions.
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
okay
